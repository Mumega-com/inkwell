# Inkwell Design System

> The visual vocabulary of **Inkwell** — an AI-first CMS packaged as a complete, forkable business operating system. Dark-first, mono-forward, publishing-grade.

Inkwell is a CMS that treats agents as first-class authors. v3 ships the content engine (Astro + MDX + wikilinks + search). v4 layers a full business OS on top: dashboard, contracts, payments, chat, Telegram steering, MCP server, daily analytics flywheel. One config file (`inkwell.config.ts`) drives every surface — fork the repo, edit the config, let the agent run it.

**Personality.** Builder, not marketer. Technical but plain-spoken. Dark backgrounds with ink-gold accents. Every heading in JetBrains Mono, every body line in system sans. Engineering docs energy with a small-business-owner's warmth.

---

## Sources

All tokens, components, and patterns in this system are lifted from:

- **Repo:** [`Mumega-com/inkwell`](https://github.com/Mumega-com/inkwell) @ `main`
- **Config:** `inkwell.config.ts` — theme colors, fonts, radii, feature flags
- **Base CSS:** `src/styles/base.css` — prose, block types, interaction states
- **Theme generator:** `src/lib/theme.ts` — config → CSS custom properties
- **Components:** 23 TSX files under `src/components/` (charts, engagement, navigation, visualization, forms, dashboard, chat)
- **Content strategy:** `CONTENT_STRATEGY.md`
- **Agent contract:** `CLAUDE.md`
- **Roadmap:** `ROADMAP.md`

The archived source also lives in this project under `_inkwell_src/` for local reference — the UI kit in `ui_kits/` is the canonical recreation.

---

## Index

| Path | What's there |
|------|--------------|
| `README.md` | This file — context, content fundamentals, visual foundations, iconography |
| `colors_and_type.css` | Canonical CSS custom properties + semantic type classes |
| `SKILL.md` | Agent skill manifest (reuse this as a Claude Code skill) |
| `assets/` | Favicon + exported logo / wordmark assets |
| `fonts/` | Flagged — fonts are loaded from Google Fonts CDN (see Visual Foundations) |
| `preview/` | Design-system preview cards (colors, type, spacing, components, brand) |
| `ui_kits/inkwell-site/` | Marketing site UI kit — landing, blog, post, docs |
| `ui_kits/inkwell-dashboard/` | v4 business dashboard UI kit — overview, tables, charts, chat widget |
| `_inkwell_src/` | Imported reference source from `Mumega-com/inkwell` |

---

## Content Fundamentals

Inkwell's copy is engineered more than it is written. The voice across the marketing site, docs, dashboard, and product UI holds a tight line:

**Voice**
- **Builder, not marketer.** Every claim is backed by something the repo can prove — a post, a feature, a working integration. Marketing fluff reads as broken tone.
- **Technical but accessible.** Assume the reader knows what a static site generator is, but define FRC / MCP / SOS on first mention.
- **Opinionated but evidence-based.** "Inkwell doesn't do X because Y" is fine. "Inkwell is the best CMS ever" is not.
- **Project-perspective, not generic AI.** Write as *Inkwell*, not as an assistant. First-person plural for the project; second-person for the reader.

**Casing & rhythm**
- **Sentence case** for UI labels, buttons, nav, table headers — *not* Title Case.
- **Monocaps with letter-spacing** for meta labels (eyebrows, status badges, kbd hints): `UPPERCASE`, `letter-spacing: 0.05em`, 11–12px, JetBrains Mono.
- Short declarative sentences. Code-review prose. Lists > paragraphs where the semantics allow.
- The em-dash is the house punctuation — used to pivot, not to decorate.

**Pronoun rules**
- **"You"** for the reader / developer / fork-operator. "Fork it. Configure it. Let the agent run it."
- **"We"** for the Inkwell project when speaking about decisions or roadmap.
- **"The agent"** or a named agent (`inkwell-web`) when describing autonomous behavior. Never "AI" as a generic noun.

**Emoji & symbolic copy**
- **No decorative emoji** in UI. None in nav, buttons, CTAs, badges.
- Reactions (🔥 ❤️ 🧠 👏 🚀) are the single allowed exception — they're user-facing reaction targets, not decoration.
- Unicode glyphs *are* used as iconography in data contexts: `▲` / `▼` for trend direction, `—` for null cells, `·` as a separator, `→` in CTAs.

**Specimen copy (verbatim from the repo)**

> Tagline: *The business operating system. Fork it. Configure it. Let the agent run it.*

> Mandates (from `llms.txt`): Perfect Interconnectedness · Stripe Quality · Agentic Legibility.

> Chat greeting: *"Hi! I'm the Viamar Assistant. Ask me about shipping quotes, documents, transit times, or insurance."* (The default fork is a vehicle-shipping business; the template stays the same, the name and domain change.)

> Error state: *"Sorry, I couldn't connect. Please try again or call 1-800-277-7570."*

> Empty state (data table): simply **`—`** or `No data`. Never "Oops!" or "Nothing to see here."

> KPI card trend: `▲ 12.4% vs last period`. Never "up 12%".

> Pillar names (content strategy): **Vision · Publishing · Technology · People · Examples.** Five words, no subtitles.

---

## Visual Foundations

### Palette

Dark-first. The design was authored against `#0A0A10` and the light theme is a polite fallback. Color does three jobs only — brand signal, data encoding, and state.

| Role | Dark | Light | Notes |
|------|------|-------|-------|
| `--ink-primary` | `#D4A017` | `#D4A017` | Ink gold. Brand, CTAs, emphasis, active states, selection highlight. |
| `--ink-secondary` | `#06B6D4` | `#06B6D4` | Cyan. Data accent, links inside charts, secondary emphasis. |
| `--ink-accent` | `#10B981` | `#10B981` | Emerald. Success, positive trend, online dot, status: active. |
| `--ink-danger` | `#EF4444` | `#EF4444` | Red. Destructive, negative trend, status: closed. |
| `--ink-bg` | `#0A0A10` | `#FAFBFC` | Canvas. |
| `--ink-surface` | `#151519` | `#FFFFFF` | Cards, panels, inputs, table rows. |
| `--ink-text` | `#EDEDF0` | `#1A1D23` | Body copy. |
| `--ink-muted` | `rgba(255,255,255,0.55)` | `rgba(0,0,0,0.55)` | Secondary text, labels, axis ticks. |
| `--ink-dim` | `rgba(255,255,255,0.35)` | `rgba(0,0,0,0.35)` | Tertiary / hints / kbd. |
| `--ink-border` | `rgba(255,255,255,0.10)` | `rgba(0,0,0,0.10)` | Hairlines everywhere — never a darker solid border. |

Derived tokens (auto-generated by `theme.ts`):
- `--ink-surface-hover`: `rgba(255,255,255,0.06)` dark / `rgba(0,0,0,0.04)` light
- `--ink-primary-muted`: `#D4A0171A` (primary at 10%) — selection, pill backgrounds, tag bg

**Selection highlight** is gold @ 30% — one of the only places you'll see a translucent primary fill.

**Chart colors** extend the core with `#8B5CF6` (violet), `#F59E0B` (amber), `#EC4899` (pink) for 4–6 series.

### Typography

Two families, used with discipline.

- **Display / Mono:** `JetBrains Mono` (400, 500, 600, 700). Every heading, every metric value, every status badge, every kbd hint, every table header, every eyebrow. The monospaced heading is Inkwell's single loudest stylistic choice — it reads as a dev tool, not a blog.
- **Body:** `system-ui, -apple-system, sans-serif`. Paragraphs, form input, chat messages, nav items. System sans lets each fork feel native to its OS.

**Type scale** (from `base.css` `.ink-prose`):
- H1 `2.25rem` / 700 / `-0.02em`
- H2 `1.75rem` / 700 / `-0.02em`
- H3 `1.375rem` / 600 / `-0.015em`
- H4 `1.125rem` / 600
- Body `1rem` / line-height 1.8 (prose) or 1.6 (UI)
- Small / caption `0.875rem` / 0.75rem
- Eyebrow / kbd / status: `0.72–0.78rem` mono, uppercase, `letter-spacing: 0.05–0.08em`

**Numbers are always mono.** Metric values (`--ink-primary`, 2.5rem, 700) use the display stack; table cells with numeric data likewise. This is a hard rule — the mono digits are load-bearing for the "builder" tone.

### Spacing, radii, borders

- Base unit is 4px. Common steps: 4, 8, 12, 16, 20, 24, 32.
- Radius is **`6px` globally** (`--ink-radius`). Pills (reaction chips, status badges) are `12px`–`9999px`. Chat bubbles use asymmetric rounding (`12px 12px 2px 12px` for user, mirrored for bot) — the one piece of expressive geometry in the system.
- Borders are always `1px solid var(--ink-border)` — hairline, low-contrast. There are no heavy strokes, no colored outlines except the focus/active state where the border flips to `--ink-primary`.

### Surfaces, shadows, elevation

- Cards: `background: var(--ink-surface); border: 1px solid var(--ink-border); border-radius: 6px;` — no shadow in the resting state. Depth comes from tone, not shadow.
- Floating UI (chat panel, command palette, modals): a real shadow is allowed — `box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5)` for command palette, `0 4px 16px rgba(0,0,0,0.4)` for the chat FAB.
- **No neumorphism. No inner shadows. No glows.**
- No colored "protection gradients" — the one gradient in the system is the reading-progress bar: `linear-gradient(to right, --ink-primary, --ink-secondary)`, 3px tall, fixed top.

### Backgrounds & imagery

- **No background images or textures.** The site is solid fills on `--ink-bg`. No noise, no grain, no blurred gradients.
- The hero on the marketing site is a **canvas-animated network graph** (`NetworkHero.tsx`) — organic node clusters in agent/tool/topic/lab colors, subtly animated. This is the only "illustration" surface; everything else is type + data + chrome.
- Imagery in blog posts is `border-radius: 6px`, no shadow, flush to content width. No filters.

### Motion

- Hover / theme / color transitions: **`200ms ease`** on `background-color`, `color`, `opacity`, `border-color`. Canonical duration.
- Micro-interactions (reaction tap, button press): `150ms` with a tiny scale pulse (`scale(1.15)` for 300ms, then return) — used sparingly, only on reactions.
- Chat panel enter: `transform: translateY(12px) scale(0.97) → translateY(0) scale(1)` over 200ms.
- Page load: no entrance animation. The reading-progress bar is the only persistent motion.
- **No bounces. No parallax. No scroll-linked animation.** Respect `prefers-reduced-motion` implicitly by keeping durations short.

### Interaction states

- **Hover (buttons, nav, table rows):** `opacity: 0.85–0.9` for filled elements; `background: var(--ink-surface-hover)` (5% tint) for surface rows; border flips to `--ink-primary` on inputs and chip toggles.
- **Active / selected:** 2px left accent bar in `--ink-primary` (command palette items), or border recolored to `--ink-primary` + `background: var(--ink-primary-muted)` (reaction chips).
- **Pressed / submitted:** `opacity: 0.5`, `cursor: default`. No shrink.
- **Focus:** default `outline` removed; `border-color: var(--ink-primary)` on inputs; interactive elements use the natural hover style.
- **Disabled:** `opacity: 0.4–0.5`, `cursor: not-allowed`.

### Layout rules

- Max content width: **`680px`** for prose (`--ink-content-width`); **`1200px`** for pages (`--ink-page-width`).
- TOC: 220px sticky sidebar on post pages, hidden < 768px.
- Dashboard: sidebar nav on desktop ≥ 768px, bottom tab bar below. Same breakpoint for chat panel (desktop: floating 380×500px; mobile: bottom sheet, 70vh).
- No fixed headers on the marketing site — the header is sticky only with a 1px bottom hairline. The reading-progress bar is the only fixed top-of-viewport element.
- Transparency/blur: **none.** No backdrop-filter, no glassmorphism.

### Cards — the canonical pattern

```css
background: var(--ink-surface);
border: 1px solid var(--ink-border);
border-radius: var(--ink-radius);  /* 6px */
padding: 1.25rem 1.5rem;
/* no shadow in resting state */
```

Every KPI, chart, table, form, chat panel, command palette result list, and content callout uses this same envelope. Variety comes from what's *inside*, not from the card.

---

## Iconography

**Approach: pragmatic and sparse.** Inkwell is a text-and-data product; icons are used only where a glyph reads faster than a word.

**What's in the repo**
- **No icon library is installed.** No Lucide, Heroicons, Phosphor, or custom sprite. `package.json` has no icon dependency.
- **Icons in-product are hand-authored inline SVGs** — you'll find them directly in TSX: the send arrow in `ChatWidget.tsx` (`<path d="M14 2L7 9…" />`), the close X, the chat bubble. 16–22px, 1.8px stroke, `round` caps and joins, single color (`currentColor` or `white`).
- **The favicon** (`assets/inkwell-favicon.svg`) is a stylized "A" in an inkwell — a solid-fill glyph that adapts to dark/light via a `@media (prefers-color-scheme)` rule inside the SVG itself.
- **The reading-progress bar** is a gradient rectangle — not an icon but it's the only visual motif that isn't type or data.

**Unicode as icons**
- `▲` / `▼` — trend indicators on KPI cards
- `—` — empty / null cell in tables and KPIs
- `→` in CTAs and inline links, where space allows
- `·` as a separator between meta fields

**Emoji**
- Reactions only: 🔥 ❤️ 🧠 👏 🚀 (literal `EMOJIS` array in `Reactions.tsx`). These are the react targets, not decoration.
- Zero elsewhere.

**In this design system**
- **Primary:** the handful of inline SVGs lifted from the source, reused in `ui_kits/`.
- **Where Inkwell doesn't provide an icon** (e.g. dashboard nav, table actions), we substitute **[Lucide](https://lucide.dev)** via CDN — Lucide matches Inkwell's 1.5–1.8px, round-cap, single-stroke style almost exactly. This is a **substitution, flagged** — Inkwell ships no icon font. Document in-kit as `icon="lucide:chart-line"` so future iteration can swap in native SVGs if Inkwell adds them.
- Never draw emoji cards, never decorative SVGs, never colored icon pills. If a surface doesn't need an icon, it doesn't get one.

---

## Font Flags & Substitutions

- **`JetBrains Mono`** — shipped from Google Fonts CDN only (no local `.ttf` in the repo). This design system follows the same convention — see `colors_and_type.css` `@import` URL. **If you need Inkwell to work offline** (packaged deliverable, downloaded prototype), download JetBrains Mono 400/500/600/700 from [fonts.google.com/specimen/JetBrains+Mono](https://fonts.google.com/specimen/JetBrains+Mono) and drop into `fonts/`. Flagged — this project does not ship a local font file by default.
- **Body family** is the native `system-ui` stack — no file, no substitution needed.
