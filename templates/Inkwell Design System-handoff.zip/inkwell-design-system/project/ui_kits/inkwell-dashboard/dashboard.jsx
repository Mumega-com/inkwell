// Inkwell Dashboard — sidebar + chat widget + pages
const { useState, useEffect, useRef } = React;

const ICONS = {
  overview: <svg className="ic" viewBox="0 0 24 24"><path d="M3 12 12 4l9 8"/><path d="M5 10v10h14V10"/></svg>,
  chart:    <svg className="ic" viewBox="0 0 24 24"><path d="M4 20V4M4 20h16"/><path d="M8 16V9M12 16V6M16 16v-4"/></svg>,
  contacts: <svg className="ic" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>,
  posts:    <svg className="ic" viewBox="0 0 24 24"><path d="M6 4h10l4 4v12H6z"/><path d="M16 4v4h4M9 13h8M9 17h6"/></svg>,
  contracts:<svg className="ic" viewBox="0 0 24 24"><path d="M7 3h8l4 4v14H7z"/><path d="M15 3v4h4M9 13h6M9 17h4"/></svg>,
  settings: <svg className="ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.2-1.6l2-1.5-2-3.4-2.4.9a7 7 0 0 0-2.8-1.6L13 2h-4l-.6 2.8A7 7 0 0 0 5.6 6.4l-2.4-.9-2 3.4 2 1.5A7 7 0 0 0 3 12l-.2 1.6-2 1.5 2 3.4 2.4-.9a7 7 0 0 0 2.8 1.6L9 22h4l.6-2.8a7 7 0 0 0 2.8-1.6l2.4.9 2-3.4-2-1.5c.1-.5.2-1 .2-1.6Z"/></svg>,
  chat:     <svg className="ic" viewBox="0 0 24 24"><path d="M4 4h16v12H8l-4 4V4Z"/></svg>,
  send:     <svg viewBox="0 0 24 24"><path d="M14 2 7 9l-5 2 7 3 3 7 2-5 7-7-7 7"/><path d="M22 2 11 13"/></svg>,
  x:        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>,
};

const FAVICON_SVG = (
  <svg viewBox="0 0 128 128" aria-hidden="true">
    <path d="M50.4 78.5a75.1 75.1 0 0 0-28.5 6.9l24.2-65.7c.7-2 1.9-3.2 3.4-3.2h29c1.5 0 2.7 1.2 3.4 3.2l24.2 65.7s-11.6-7-28.5-7L67 45.5c-.4-1.7-1.6-2.8-2.9-2.8-1.3 0-2.5 1.1-2.9 2.7L50.4 78.5Zm-4.2-20.2c-2 6.6-.6 15.8 4.2 20.2a17.5 17.5 0 0 1 .2-.7 5.5 5.5 0 0 1 5.7-4.5c2.8.1 4.3 1.5 4.7 4.7.2 1.1.2 2.3.2 3.5v.4c0 2.7.7 5.2 2.2 7.4a13 13 0 0 0 5.7 4.9v-.3l-.2-.3c-1.8-5.6-.5-9.5 4.4-12.8l1.5-1a73 73 0 0 0 3.2-2.2 16 16 0 0 0 6.8-11.4c.3-2 .1-4-.6-6l-.8.6-1.6 1a37 37 0 0 1-22.4 2.7c-5-.7-9.7-2-13.2-6.2Z"/>
  </svg>
);

function Sidebar({ route, onNavigate }) {
  const nav = [
    ['ANALYZE', [['overview','Overview',null],['analytics','Analytics',null]]],
    ['ENGAGE', [['contacts','Contacts','24'],['chat','Chat inbox','3']]],
    ['CONTENT', [['posts','Posts',null],['contracts','Contracts','7']]],
    ['SYSTEM', [['settings','Settings',null]]],
  ];
  return (
    <aside className="sidebar">
      <div className="sb-brand">
        {FAVICON_SVG}
        <div className="n">Inkwell</div>
        <div className="badge">v4</div>
      </div>
      {nav.map(([group, items])=>(
        <div className="sb-group" key={group}>
          <div className="label">{group}</div>
          {items.map(([slug,label,count])=>(
            <a key={slug} href="#" onClick={(e)=>{e.preventDefault(); onNavigate(slug);}}
               className={`sb-item ${route===slug?'active':''}`}>
              {ICONS[slug] || ICONS.overview}
              <span>{label}</span>
              {count && <span className="count">{count}</span>}
            </a>
          ))}
        </div>
      ))}
      <div style={{marginTop:'auto', padding:'12px 8px', fontFamily:'var(--ink-font-mono)', fontSize:10, color:'var(--ink-dim)', textTransform:'uppercase', letterSpacing:'0.06em'}}>
        fork · configure · run
      </div>
    </aside>
  );
}

function Topbar({ route }) {
  const crumbs = { overview:'Home / Overview', analytics:'Home / Analytics', contacts:'Home / Contacts', chat:'Home / Chat inbox', posts:'Home / Content / Posts', contracts:'Home / Content / Contracts', settings:'Home / Settings' };
  const titles = { overview:'Overview', analytics:'Analytics', contacts:'Contacts', chat:'Chat inbox', posts:'Posts', contracts:'Contracts', settings:'Settings' };
  return (
    <div className="topbar">
      <div>
        <div className="crumbs">{crumbs[route]}</div>
        <div className="title" style={{marginTop:2}}>{titles[route]}</div>
      </div>
      <div className="topbar-right">
        <input className="search" placeholder="Search anything…"/>
        <div className="avatar">M</div>
      </div>
    </div>
  );
}

// Simple sparkline / chart
function TrendChart({ data, height=180, accent='var(--ink-primary)' }) {
  const w = 820, h = height, pad = 28;
  const max = Math.max(...data), min = Math.min(...data);
  const range = max - min || 1;
  const pts = data.map((d,i)=>{
    const x = pad + (i/(data.length-1)) * (w-pad*2);
    const y = h-pad - ((d-min)/range) * (h-pad*2);
    return [x,y];
  });
  const path = pts.map((p,i)=> (i===0?'M':'L')+p[0].toFixed(1)+','+p[1].toFixed(1)).join(' ');
  const area = path + ` L${pts[pts.length-1][0]},${h-pad} L${pts[0][0]},${h-pad} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} style={{width:'100%', height:h, display:'block'}}>
      <defs>
        <linearGradient id="g1" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={accent} stopOpacity="0.25"/>
          <stop offset="100%" stopColor={accent} stopOpacity="0"/>
        </linearGradient>
      </defs>
      {[0.25,0.5,0.75,1].map(r => (
        <line key={r} x1={pad} x2={w-pad} y1={h-pad-r*(h-pad*2)} y2={h-pad-r*(h-pad*2)} stroke="rgba(255,255,255,0.06)" strokeDasharray="3 3"/>
      ))}
      <path d={area} fill="url(#g1)"/>
      <path d={path} fill="none" stroke={accent} strokeWidth="2"/>
      {pts.map((p,i)=>i%4===0 && <circle key={i} cx={p[0]} cy={p[1]} r="2.5" fill={accent}/>)}
    </svg>
  );
}

function Overview() {
  const sessionsData = [120,145,160,142,188,215,198,223,245,232,270,265,298,320,312,340,355,338,372,398];
  return (
    <div>
      <div className="page-head">
        <div>
          <h1>Overview</h1>
          <p>Apr 1 – Apr 17 · compared to previous 17 days</p>
        </div>
        <div style={{display:'flex',gap:8}}>
          <button className="btn btn-ghost" style={{padding:'7px 14px',fontSize:12,background:'var(--ink-surface)',border:'1px solid var(--ink-border)',borderRadius:4,color:'var(--ink-text)',fontFamily:'var(--ink-font-mono)',cursor:'pointer'}}>Last 17 days ▾</button>
          <button style={{padding:'7px 14px',fontSize:12,background:'var(--ink-primary)',color:'#0A0A10',borderRadius:4,border:'none',fontFamily:'var(--ink-font-mono)',fontWeight:600,cursor:'pointer'}}>Export</button>
        </div>
      </div>

      <div className="kpi-grid">
        {[
          ['Sessions','12,482','▲ 12.4%', true],
          ['Leads','147','▲ 8.3%', true],
          ['Posts published','23','▲ 15.0%', true],
          ['Bounce rate','38.1%','▼ 4.2%', true],
        ].map(([t,v,tr,up])=>(
          <div className="kpi" key={t}>
            <div className="title">{t}</div>
            <div className="value">{v}</div>
            <div className={up?'trend-up':'trend-down'}>{tr} vs last period</div>
          </div>
        ))}
      </div>

      <div style={{display:'grid',gridTemplateColumns:'2fr 1fr',gap:14,marginBottom:14}}>
        <div className="panel">
          <div className="panel-head">
            <h2>Sessions</h2>
            <div style={{display:'flex',gap:8,fontFamily:'var(--ink-font-mono)',fontSize:11,color:'var(--ink-muted)'}}>
              <span style={{color:'var(--ink-primary)'}}>● this period</span>
              <span>● previous</span>
            </div>
          </div>
          <TrendChart data={sessionsData}/>
        </div>
        <div className="panel">
          <div className="panel-head"><h2>Top pages</h2></div>
          <div style={{display:'flex',flexDirection:'column',gap:10}}>
            {[
              ['/blog/agent-powered-publishing', 2840, 0.86],
              ['/docs/getting-started', 1976, 0.72],
              ['/blog/flywheel-online', 1422, 0.58],
              ['/docs/publishing', 983, 0.41],
              ['/labs', 612, 0.28],
            ].map(([u,v,r])=>(
              <div key={u}>
                <div style={{display:'flex',justifyContent:'space-between',marginBottom:4}}>
                  <span style={{fontFamily:'var(--ink-font-mono)',fontSize:12,color:'var(--ink-text)'}}>{u}</span>
                  <span className="num" style={{fontFamily:'var(--ink-font-mono)',fontSize:11,color:'var(--ink-muted)'}}>{v.toLocaleString()}</span>
                </div>
                <div style={{height:3,background:'rgba(255,255,255,0.05)',borderRadius:2,overflow:'hidden'}}>
                  <div style={{height:'100%',width:`${r*100}%`,background:'var(--ink-primary)'}}></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
        <div className="panel">
          <div className="panel-head"><h2>Recent leads</h2><a href="#" style={{fontSize:12,color:'var(--ink-primary)',textDecoration:'none',fontFamily:'var(--ink-font-mono)'}}>View all →</a></div>
          <table className="table">
            <tbody>
              {[
                ['D. Khoury','kh@studio.ca','3m ago','new'],
                ['R. Aoun','r.aoun@…','47m ago','contacted'],
                ['M. Boutros','mbt@mail','2h ago','active'],
                ['Anonymous','—','5h ago','closed'],
              ].map(([n,e,t,s])=>(
                <tr key={n+t}><td>{n}</td><td style={{color:'var(--ink-muted)'}}>{e}</td><td className="num" style={{color:'var(--ink-muted)'}}>{t}</td><td><span className={`badge b-${s==='new'?'new':s==='contacted'?'cont':s==='active'?'active':'closed'}`}>{s}</span></td></tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="panel">
          <div className="panel-head"><h2>Agent activity</h2><span style={{fontFamily:'var(--ink-font-mono)',fontSize:10,color:'var(--ink-primary)'}}>● LIVE</span></div>
          <div style={{display:'flex',flexDirection:'column',gap:12}}>
            {[
              ['09:14','Published','agent-powered publishing','▲ 14 reads/hr'],
              ['08:42','Analyzed','weekly flywheel digest','3 gaps identified'],
              ['07:58','Replied','chat session · shipping quote','resolved'],
              ['07:30','Ingested','2 markdown files from inbox','validated'],
            ].map(([t,v,what,meta])=>(
              <div key={t+what} style={{display:'grid',gridTemplateColumns:'48px auto 1fr',gap:10,alignItems:'baseline'}}>
                <span className="num" style={{fontFamily:'var(--ink-font-mono)',fontSize:11,color:'var(--ink-dim)'}}>{t}</span>
                <span style={{fontFamily:'var(--ink-font-mono)',fontSize:10,textTransform:'uppercase',letterSpacing:'0.05em',color:'var(--ink-primary)'}}>{v}</span>
                <div style={{fontSize:13}}>
                  <div style={{color:'var(--ink-text)'}}>{what}</div>
                  <div style={{color:'var(--ink-muted)',fontSize:12,marginTop:2}}>{meta}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function Contacts() {
  const rows = [
    ['Dina Khoury','kh@studio.ca','new','form','apr 17','—'],
    ['Rami Aoun','r.aoun@mail.com','contacted','chat','apr 17','4'],
    ['Mary Boutros','mbt@mail.com','active','referral','apr 16','12'],
    ['John Smith','js@acme.co','active','organic','apr 15','7'],
    ['Anon visitor','—','closed','chat','apr 15','2'],
    ['Lena Saad','l.saad@mail.com','new','form','apr 14','—'],
    ['Omar Najjar','o.najjar@mail.com','contacted','chat','apr 14','3'],
    ['Z. Farah','z.farah@design.co','active','referral','apr 12','9'],
  ];
  const [filter, setFilter] = useState('all');
  const filtered = filter==='all' ? rows : rows.filter(r=>r[2]===filter);
  return (
    <div>
      <div className="page-head">
        <div><h1>Contacts</h1><p>{filtered.length} of {rows.length} · all sources</p></div>
        <button style={{padding:'8px 16px',fontSize:12,background:'var(--ink-primary)',color:'#0A0A10',borderRadius:4,border:'none',fontFamily:'var(--ink-font-mono)',fontWeight:600,cursor:'pointer'}}>+ New contact</button>
      </div>
      <div className="panel">
        <div style={{display:'flex',gap:8,marginBottom:14,flexWrap:'wrap'}}>
          {[['all','All'],['new','New'],['contacted','Contacted'],['active','Active'],['closed','Closed']].map(([k,l])=>(
            <button key={k} onClick={()=>setFilter(k)} style={{padding:'5px 12px',borderRadius:12,border:`1px solid ${filter===k?'var(--ink-primary)':'var(--ink-border)'}`,background:filter===k?'rgba(212,160,23,0.10)':'transparent',color:filter===k?'var(--ink-primary)':'var(--ink-muted)',fontFamily:'var(--ink-font-mono)',fontSize:11,textTransform:'uppercase',letterSpacing:'0.05em',cursor:'pointer'}}>{l}</button>
          ))}
        </div>
        <table className="table">
          <thead><tr><th>Name</th><th>Email</th><th>Status</th><th>Source</th><th>Last seen</th><th>Messages</th></tr></thead>
          <tbody>
            {filtered.map((r,i)=>(
              <tr key={i}>
                <td style={{fontWeight:600}}>{r[0]}</td>
                <td style={{color:'var(--ink-muted)'}}>{r[1]}</td>
                <td><span className={`badge b-${r[2]==='new'?'new':r[2]==='contacted'?'cont':r[2]==='active'?'active':'closed'}`}>{r[2]}</span></td>
                <td style={{color:'var(--ink-muted)'}}>{r[3]}</td>
                <td className="num" style={{color:'var(--ink-muted)'}}>{r[4]}</td>
                <td className="num">{r[5]}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Posts() {
  const rows = [
    ['Agent-powered publishing with Inkwell','publishing','active','apr 17','2,840','12'],
    ['The flywheel is online','vision','active','apr 10','1,422','8'],
    ['Why Inkwell is dark by default','technology','active','apr 02','983','15'],
    ['MCP server, 1.0','technology','active','mar 28','1,104','7'],
    ['Building Viamar on an Inkwell fork','examples','active','mar 22','872','4'],
    ['What I ship, what the agent ships','people','active','mar 18','612','9'],
    ['The 9am telegram','publishing','draft','—','—','—'],
    ['Zod frontmatter, one year in','technology','active','mar 04','547','3'],
  ];
  return (
    <div>
      <div className="page-head">
        <div><h1>Posts</h1><p>{rows.length} across blog · docs · labs</p></div>
        <div style={{display:'flex',gap:8}}>
          <button className="btn btn-ghost" style={{padding:'7px 14px',fontSize:12,background:'var(--ink-surface)',border:'1px solid var(--ink-border)',borderRadius:4,color:'var(--ink-text)',fontFamily:'var(--ink-font-mono)',cursor:'pointer'}}>Ingest inbox</button>
          <button style={{padding:'7px 14px',fontSize:12,background:'var(--ink-primary)',color:'#0A0A10',borderRadius:4,border:'none',fontFamily:'var(--ink-font-mono)',fontWeight:600,cursor:'pointer'}}>+ New post</button>
        </div>
      </div>
      <div className="panel">
        <table className="table">
          <thead><tr><th>Title</th><th>Pillar</th><th>Status</th><th>Published</th><th>Views</th><th>Reacts</th></tr></thead>
          <tbody>
            {rows.map((r,i)=>(
              <tr key={i}>
                <td style={{fontFamily:'var(--ink-font-display)',fontWeight:600}}>{r[0]}</td>
                <td><span className="badge b-cont">{r[1]}</span></td>
                <td><span className={`badge b-${r[2]==='active'?'active':'draft'}`}>{r[2]}</span></td>
                <td className="num" style={{color:'var(--ink-muted)'}}>{r[3]}</td>
                <td className="num">{r[4]}</td>
                <td className="num">{r[5]}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Settings() {
  return (
    <div>
      <div className="page-head"><div><h1>Settings</h1><p>Driven by <code className="ink-code">inkwell.config.ts</code> · changes here are proposed as PRs.</p></div></div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
        <div className="panel">
          <div className="panel-head"><h2>Site identity</h2></div>
          <div style={{display:'flex',flexDirection:'column',gap:12}}>
            <div><label style={{fontFamily:'var(--ink-font-mono)',fontSize:10,textTransform:'uppercase',letterSpacing:'0.08em',color:'var(--ink-muted)',display:'block',marginBottom:6}}>name</label><input defaultValue="Inkwell" style={inputStyle}/></div>
            <div><label style={labelStyle}>tagline</label><input defaultValue="Fork it. Configure it. Let the agent run it." style={inputStyle}/></div>
            <div><label style={labelStyle}>domain</label><input defaultValue="inkwell.dev" style={inputStyle}/></div>
          </div>
        </div>
        <div className="panel">
          <div className="panel-head"><h2>Theme</h2></div>
          <div style={{display:'flex',flexDirection:'column',gap:12}}>
            <div><label style={labelStyle}>primary</label><div style={{display:'flex',gap:8,alignItems:'center'}}><div style={{width:28,height:28,borderRadius:4,background:'#D4A017'}}/><input defaultValue="#D4A017" style={{...inputStyle,fontFamily:'var(--ink-font-mono)'}}/></div></div>
            <div><label style={labelStyle}>radius</label><input defaultValue="6" style={{...inputStyle,fontFamily:'var(--ink-font-mono)'}}/></div>
            <div><label style={labelStyle}>dark by default</label><div style={{display:'flex',gap:12,alignItems:'center'}}><span style={{width:36,height:20,borderRadius:10,background:'var(--ink-primary)',position:'relative',cursor:'pointer'}}><span style={{position:'absolute',top:2,left:18,width:16,height:16,borderRadius:'50%',background:'#0A0A10'}}/></span><span style={{fontFamily:'var(--ink-font-mono)',fontSize:12,color:'var(--ink-primary)'}}>ON</span></div></div>
          </div>
        </div>
        <div className="panel">
          <div className="panel-head"><h2>Features</h2></div>
          {[['chat','Chat widget',true],['mcp','MCP server',true],['telegram','Telegram steering',true],['payments','Stripe payments',false]].map(([k,l,on])=>(
            <div key={k} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'10px 0',borderBottom:'1px solid var(--ink-border)'}}>
              <span style={{fontSize:14}}>{l}</span>
              <span style={{fontFamily:'var(--ink-font-mono)',fontSize:11,textTransform:'uppercase',color:on?'var(--ink-accent)':'var(--ink-dim)'}}>{on?'enabled':'off'}</span>
            </div>
          ))}
        </div>
        <div className="panel">
          <div className="panel-head"><h2>Agents</h2></div>
          {[['inkwell-web','Publishes site','apr 17 · 09:14'],['inkwell-ops','Dashboard + chat','apr 17 · 09:12']].map(([n,d,seen])=>(
            <div key={n} style={{display:'flex',justifyContent:'space-between',alignItems:'baseline',padding:'10px 0',borderBottom:'1px solid var(--ink-border)'}}>
              <div>
                <div style={{fontFamily:'var(--ink-font-display)',fontSize:14,fontWeight:600}}>{n}</div>
                <div style={{fontSize:12,color:'var(--ink-muted)'}}>{d}</div>
              </div>
              <div style={{fontFamily:'var(--ink-font-mono)',fontSize:11,color:'var(--ink-dim)'}}>{seen}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const inputStyle = { width:'100%', boxSizing:'border-box', padding:'8px 12px', borderRadius:4, background:'var(--ink-bg)', border:'1px solid var(--ink-border)', color:'var(--ink-text)', fontSize:14, outline:'none', fontFamily:'var(--ink-font-body)' };
const labelStyle = { fontFamily:'var(--ink-font-mono)', fontSize:10, textTransform:'uppercase', letterSpacing:'0.08em', color:'var(--ink-muted)', display:'block', marginBottom:6 };

function ChatInbox() {
  const sessions = [
    ['Dina Khoury','Need a quote for 2 pallets…','3m','active'],
    ['Rami Aoun','Thanks! When would transit be?','47m','active'],
    ['Mary Boutros','All set, thanks.','2h','closed'],
    ['Anon','Hi — do you ship to QC?','5h','closed'],
  ];
  return (
    <div>
      <div className="page-head"><div><h1>Chat inbox</h1><p>3 active · 2 resolved today</p></div></div>
      <div className="panel" style={{padding:0, overflow:'hidden'}}>
        <div style={{display:'grid',gridTemplateColumns:'300px 1fr',minHeight:460}}>
          <div style={{borderRight:'1px solid var(--ink-border)',overflow:'auto'}}>
            {sessions.map((s,i)=>(
              <div key={i} style={{padding:'14px 16px',borderBottom:'1px solid var(--ink-border)',cursor:'pointer', background: i===0?'rgba(212,160,23,0.08)':'transparent',borderLeft: i===0?'2px solid var(--ink-primary)':'2px solid transparent'}}>
                <div style={{display:'flex',justifyContent:'space-between',marginBottom:4}}>
                  <span style={{fontFamily:'var(--ink-font-display)',fontSize:13,fontWeight:600}}>{s[0]}</span>
                  <span style={{fontFamily:'var(--ink-font-mono)',fontSize:10,color:'var(--ink-dim)'}}>{s[2]}</span>
                </div>
                <div style={{fontSize:12,color:'var(--ink-muted)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{s[1]}</div>
              </div>
            ))}
          </div>
          <div style={{display:'flex',flexDirection:'column'}}>
            <div style={{padding:'12px 18px',borderBottom:'1px solid var(--ink-border)',display:'flex',justifyContent:'space-between'}}>
              <div>
                <div style={{fontFamily:'var(--ink-font-display)',fontSize:14,fontWeight:600}}>Dina Khoury</div>
                <div style={{fontSize:12,color:'var(--ink-muted)'}}>kh@studio.ca · started 3m ago</div>
              </div>
              <span className="badge b-active">active</span>
            </div>
            <div style={{flex:1,padding:16,display:'flex',flexDirection:'column',gap:8,background:'var(--ink-bg)',overflow:'auto'}}>
              <div className="msg-bot">Hi! I'm the Inkwell Assistant. Ask me about publishing, the flywheel, or anything else.</div>
              <div className="msg-user">Need a quote for 2 pallets from Toronto to Montreal.</div>
              <div className="msg-bot">Got it — shared LTL or dedicated? Typical transit 2 business days.</div>
              <div className="msg-user">Shared is fine.</div>
              <div className="msg-bot">Estimated $340 CAD + tax, pickup tomorrow. Want me to book?</div>
            </div>
            <div className="chat-input">
              <input placeholder="Type a reply…"/>
              <button>{ICONS.send}</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ChatFAB() {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState([
    { role:'bot', text:"Hi! I'm the Inkwell Assistant. Ask me about publishing, the flywheel, or the MCP tools." },
  ]);
  const [q, setQ] = useState('');
  function send(){
    if (!q.trim()) return;
    const userMsg = { role:'user', text: q };
    setMsgs(m=>[...m, userMsg]); setQ('');
    setTimeout(()=>{
      setMsgs(m=>[...m, { role:'bot', text:"Drop markdown in content/inbox/ then run npm run publish — the ingest script moves it and validates frontmatter." }]);
    }, 700);
  }
  return (
    <>
      {open && (
        <div className="chat-panel">
          <div className="chat-head">
            <div className="who"><span className="dot"></span><span className="name">Inkwell Assistant</span></div>
            <button className="x" onClick={()=>setOpen(false)}>{ICONS.x}</button>
          </div>
          <div className="chat-body">
            {msgs.map((m,i)=>(<div key={i} className={m.role==='user'?'msg-user':'msg-bot'}>{m.text}</div>))}
          </div>
          <div className="chat-input">
            <input value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>{if(e.key==='Enter') send();}} placeholder="Ask anything…"/>
            <button onClick={send}>{ICONS.send}</button>
          </div>
        </div>
      )}
      {!open && <button className="chat-fab" onClick={()=>setOpen(true)}>{ICONS.chat}</button>}
    </>
  );
}

Object.assign(window, { Sidebar, Topbar, Overview, Contacts, Posts, Settings, ChatInbox, ChatFAB });
