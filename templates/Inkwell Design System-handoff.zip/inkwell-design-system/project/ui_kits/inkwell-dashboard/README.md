# Inkwell Dashboard — UI Kit

The v4 business operating system surface, recreated from `Mumega-com/inkwell/src/components/dashboard/`, `/engagement/`, `/forms/`, `/charts/`, and `ChatWidget.tsx`.

- **Views:** Overview (KPIs + trend chart + recent activity), Contacts (table + filters), Posts (content table with reactions), Settings.
- **Persistent chat widget** floats bottom-right on every view — the one piece of product chrome that follows the user.
- **Sidebar nav** on desktop ≥ 768px; stacked bottom tabs below.

Open `index.html`.
