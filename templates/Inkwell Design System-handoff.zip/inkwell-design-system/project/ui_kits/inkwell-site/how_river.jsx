// Inkwell — How it works (ingest pipeline) + River (ops agent)
const { useState: useStateHR, useEffect: useEffectHR, useRef: useRefHR } = React;

function HowItWorks() {
  const [hovered, setHovered] = useStateHR(null);
  const nodes = [
    { id: 'inbox', x: 60,  y: 110, label: 'Inbox', desc: 'MCP call lands from Claude, ChatGPT, Gemini, or Cursor. Raw markdown + intent.' },
    { id: 'ingest', x: 220, y: 110, label: 'Ingest', desc: 'River parses frontmatter, pillar, and content type. Nothing written yet.' },
    { id: 'zod', x: 380, y: 60, label: 'Zod validate', desc: 'Collection schema enforced. Missing field → PR blocked with a clear error.' },
    { id: 'wiki', x: 380, y: 160, label: 'Wikilinks', desc: '[[Post]] resolves to canonical slugs. Broken links fail the build.' },
    { id: 'back', x: 540, y: 160, label: 'Backlinks', desc: 'Every mention indexed. Linked posts auto-surface an inbound-links section.' },
    { id: 'build', x: 700, y: 110, label: 'Astro build', desc: 'Static HTML + JSON-LD + llms.txt + sitemap.xml emitted. Fully typed output.' },
    { id: 'cdn',   x: 860, y: 110, label: 'Cloudflare', desc: 'Deployed to edge. TTFB ~40ms warm. Invalidations pushed globally.' },
  ];
  const edges = [
    ['inbox', 'ingest'],
    ['ingest', 'zod'],
    ['ingest', 'wiki'],
    ['zod', 'build'],
    ['wiki', 'back'],
    ['back', 'build'],
    ['build', 'cdn'],
  ];
  const byId = Object.fromEntries(nodes.map(n => [n.id, n]));
  const active = hovered ? byId[hovered] : null;

  return (
    <div>
      <section style={{ padding: '64px 0 24px' }}>
        <Eyebrow>How it works · ingest to edge</Eyebrow>
        <h1 style={{ fontFamily: 'var(--ink-font-display)', fontSize: '3rem', fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1.05, margin: '14px 0 16px', maxWidth: 760 }}>
          Seven stages between your AI and the CDN.
        </h1>
        <p style={{ fontSize: 17, lineHeight: 1.55, color: 'var(--ink-muted)', margin: '0 0 32px', maxWidth: 620 }}>
          Hover any node to see what it does. If a stage fails, the PR never merges — your site can't ship broken content.
        </p>

        <div style={{ background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 8, padding: 24, overflow: 'hidden' }}>
          <svg viewBox="0 0 940 240" style={{ width: '100%', height: 240, display: 'block' }}>
            <defs>
              <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
                <path d="M0,0 L10,5 L0,10 z" fill="var(--ink-border-strong)" />
              </marker>
            </defs>
            {edges.map(([a, b]) => {
              const na = byId[a], nb = byId[b];
              const isActive = hovered === a || hovered === b;
              return (
                <line key={a + b} x1={na.x + 58} y1={na.y} x2={nb.x - 58} y2={nb.y}
                      stroke={isActive ? 'var(--ink-primary)' : 'var(--ink-border-strong)'}
                      strokeWidth={isActive ? 2 : 1.2}
                      markerEnd="url(#arrow)"
                      style={{ transition: 'stroke 200ms' }} />
              );
            })}
            {nodes.map(n => {
              const isActive = hovered === n.id;
              return (
                <g key={n.id} transform={`translate(${n.x}, ${n.y})`} style={{ cursor: 'pointer' }}
                   onMouseEnter={() => setHovered(n.id)} onMouseLeave={() => setHovered(null)}>
                  <rect x={-56} y={-22} width={112} height={44} rx={6}
                        fill={isActive ? 'rgba(212,160,23,0.12)' : 'var(--ink-bg)'}
                        stroke={isActive ? 'var(--ink-primary)' : 'var(--ink-border-strong)'}
                        strokeWidth={isActive ? 1.5 : 1}
                        style={{ transition: 'all 200ms' }} />
                  <text x={0} y={-2} textAnchor="middle" fontFamily="var(--ink-font-display)" fontSize={13} fontWeight={600}
                        fill={isActive ? 'var(--ink-primary)' : 'var(--ink-text)'}>{n.label}</text>
                  <text x={0} y={14} textAnchor="middle" fontFamily="var(--ink-font-mono)" fontSize={9}
                        fill="var(--ink-dim)" style={{ textTransform: 'uppercase', letterSpacing: '0.08em' }}>{n.id}</text>
                </g>
              );
            })}
          </svg>

          <div style={{ marginTop: 18, padding: '14px 18px', background: 'var(--ink-bg)', border: '1px solid var(--ink-border)', borderRadius: 6, minHeight: 60 }}>
            {active ? (
              <div>
                <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 11, color: 'var(--ink-primary)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>{active.id}</div>
                <div style={{ fontFamily: 'var(--ink-font-display)', fontSize: 15, fontWeight: 600, marginBottom: 4 }}>{active.label}</div>
                <div style={{ fontSize: 13, color: 'var(--ink-muted)', lineHeight: 1.55 }}>{active.desc}</div>
              </div>
            ) : (
              <div style={{ fontSize: 13, color: 'var(--ink-dim)', fontStyle: 'italic' }}>Hover a stage above.</div>
            )}
          </div>
        </div>
      </section>

      <section style={{ padding: '28px 0', borderTop: '1px solid var(--ink-border)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
          {[
            ['Git is the source of truth', 'Every post, every edit = a commit. Roll back anything, audit everything.'],
            ['PR-gated by default', 'River opens a pull request. You merge. Nothing touches main without you.'],
            ['Typed end-to-end', 'Zod schemas cover frontmatter, config, and emitted JSON-LD. Invalid content fails loudly.'],
          ].map(([t, d]) => (
            <div key={t} className="card" style={{ padding: '18px 20px' }}>
              <div style={{ fontFamily: 'var(--ink-font-display)', fontSize: 14, fontWeight: 600, marginBottom: 6 }}>{t}</div>
              <div style={{ fontSize: 13, color: 'var(--ink-muted)', lineHeight: 1.55 }}>{d}</div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function River() {
  const [tab, setTab] = useStateHR('does');
  const [logs, setLogs] = useStateHR([]);
  const logRef = useRefHR(null);

  useEffectHR(() => {
    if (tab !== 'log') return;
    const seq = [
      ['info',   'mcp.tool_call',      'claude → publish_post(pillar=publishing)'],
      ['info',   'ingest.parse',       'frontmatter ok · 1 wikilink detected'],
      ['ok',     'zod.validate',       'schema: blog · all required fields present'],
      ['info',   'wikilinks.resolve',  '[[Publishing]] → /publishing-warm'],
      ['ok',     'build.astro',        '12 pages · 3.1s · 0 errors'],
      ['info',   'seo.emit',           'llms.txt · sitemap.xml · 12 JSON-LD blocks'],
      ['ok',     'git.commit',         '"add(blog): publishing-warm"'],
      ['ok',     'pr.open',            'https://github.com/you/site/pull/47'],
      ['warn',   'deploy.wait',        'holding until merge · river never force-pushes'],
    ];
    let i = 0;
    const t = setInterval(() => {
      if (i >= seq.length) { clearInterval(t); return; }
      setLogs(l => [...l, { id: Date.now() + i, ts: new Date(Date.now() + i * 1000), level: seq[i][0], event: seq[i][1], msg: seq[i][2] }]);
      i++;
    }, 550);
    return () => clearInterval(t);
  }, [tab]);

  useEffectHR(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [logs]);

  const does = [
    ['Draft posts from MCP calls', 'Your AI sends markdown + intent. River shapes it into a valid content entry.'],
    ['Resolve wikilinks & backlinks', 'Rewrites [[Post]] to canonical slugs, indexes every mention.'],
    ['Open pull requests', 'Never commits to main. Every change is a PR you review.'],
    ['Run the build & validate schemas', 'Zod enforced, Astro compiled, JSON-LD verified.'],
    ['Emit SEO artifacts', 'llms.txt, sitemap.xml, OG cards, schema.org — on every build.'],
    ['Report weekly', 'Digest of what shipped, what broke, what traffic looked like.'],
  ];
  const wont = [
    ['Push to main without you', 'PRs only. You merge.'],
    ['Invent facts or citations', 'If a claim is unsourced in your draft, river flags it, not fills it in.'],
    ['Rewrite your voice', 'River formats and links. It does not re-author.'],
    ['Delete content without asking', 'Archival is a PR. Nothing is lost silently.'],
    ['Run without a config', 'No inkwell.config.ts → no river. Explicit by design.'],
  ];

  return (
    <div>
      <section style={{ padding: '64px 0 24px' }}>
        <Eyebrow>River · the default ops agent</Eyebrow>
        <h1 style={{ fontFamily: 'var(--ink-font-display)', fontSize: '3rem', fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1.05, margin: '14px 0 16px', maxWidth: 760 }}>
          The quiet one who actually ships.
        </h1>
        <p style={{ fontSize: 17, lineHeight: 1.55, color: 'var(--ink-muted)', margin: '0 0 28px', maxWidth: 620 }}>
          Claude writes. Mumega reviews. River validates, builds, opens the PR, and keeps the site out of its own way. Named after a thing that carries stuff downstream without fuss.
        </p>

        <div style={{ display: 'flex', gap: 4, marginBottom: 18, borderBottom: '1px solid var(--ink-border)' }}>
          {[['does', 'What river does'], ['wont', 'What river refuses'], ['log', 'Live log']].map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)} style={{
              background: 'transparent', border: 0, padding: '10px 16px',
              fontFamily: 'var(--ink-font-display)', fontSize: 13, fontWeight: 600,
              color: tab === k ? 'var(--ink-primary)' : 'var(--ink-muted)',
              borderBottom: `2px solid ${tab === k ? 'var(--ink-primary)' : 'transparent'}`,
              marginBottom: -1, cursor: 'pointer',
            }}>{l}</button>
          ))}
        </div>

        {tab === 'does' && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            {does.map(([t, d]) => (
              <div key={t} className="card" style={{ padding: '18px 20px' }}>
                <div style={{ fontFamily: 'var(--ink-font-display)', fontSize: 14, fontWeight: 600, marginBottom: 6, color: 'var(--ink-accent)' }}>✓ {t}</div>
                <div style={{ fontSize: 13, color: 'var(--ink-muted)', lineHeight: 1.55 }}>{d}</div>
              </div>
            ))}
          </div>
        )}

        {tab === 'wont' && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            {wont.map(([t, d]) => (
              <div key={t} className="card" style={{ padding: '18px 20px', borderColor: 'var(--ink-danger)' }}>
                <div style={{ fontFamily: 'var(--ink-font-display)', fontSize: 14, fontWeight: 600, marginBottom: 6, color: 'var(--ink-danger)' }}>✗ {t}</div>
                <div style={{ fontSize: 13, color: 'var(--ink-muted)', lineHeight: 1.55 }}>{d}</div>
              </div>
            ))}
          </div>
        )}

        {tab === 'log' && (
          <div ref={logRef} style={{
            background: '#0A0A10', border: '1px solid var(--ink-border)', borderRadius: 6,
            padding: '14px 18px', height: 340, overflow: 'auto',
            fontFamily: 'var(--ink-font-mono)', fontSize: 12, lineHeight: 1.8,
          }}>
            {logs.length === 0 && <div style={{ color: 'var(--ink-dim)' }}>river.daemon starting...</div>}
            {logs.map(l => {
              const c = l.level === 'ok' ? 'var(--ink-accent)' : l.level === 'warn' ? '#F59E0B' : l.level === 'err' ? 'var(--ink-danger)' : 'var(--ink-secondary)';
              return (
                <div key={l.id} style={{ display: 'grid', gridTemplateColumns: '70px 52px 160px 1fr', gap: 10, color: 'var(--ink-text)' }}>
                  <span style={{ color: 'var(--ink-dim)' }}>{l.ts.toTimeString().slice(0, 8)}</span>
                  <span style={{ color: c, textTransform: 'uppercase', fontWeight: 700 }}>{l.level}</span>
                  <span style={{ color: 'var(--ink-muted)' }}>{l.event}</span>
                  <span>{l.msg}</span>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}

Object.assign(window, { HowItWorks, River });
