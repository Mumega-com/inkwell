// Shared primitives for the Inkwell site UI kit
const { useState, useEffect, useRef } = React;

const FAVICON = (
  <svg viewBox="0 0 128 128" fill="none" aria-hidden="true">
    <path fill="currentColor" d="M50.4 78.5a75.1 75.1 0 0 0-28.5 6.9l24.2-65.7c.7-2 1.9-3.2 3.4-3.2h29c1.5 0 2.7 1.2 3.4 3.2l24.2 65.7s-11.6-7-28.5-7L67 45.5c-.4-1.7-1.6-2.8-2.9-2.8-1.3 0-2.5 1.1-2.9 2.7L50.4 78.5Zm-4.2-20.2c-2 6.6-.6 15.8 4.2 20.2a17.5 17.5 0 0 1 .2-.7 5.5 5.5 0 0 1 5.7-4.5c2.8.1 4.3 1.5 4.7 4.7.2 1.1.2 2.3.2 3.5v.4c0 2.7.7 5.2 2.2 7.4a13 13 0 0 0 5.7 4.9v-.3l-.2-.3c-1.8-5.6-.5-9.5 4.4-12.8l1.5-1a73 73 0 0 0 3.2-2.2 16 16 0 0 0 6.8-11.4c.3-2 .1-4-.6-6l-.8.6-1.6 1a37 37 0 0 1-22.4 2.7c-5-.7-9.7-2-13.2-6.2Z"/>
  </svg>
);

function Header({ route, onNavigate, onOpenPalette }) {
  const items = [
    { slug: 'home', label: 'Home' },
    { slug: 'architecture', label: 'Architecture' },
    { slug: 'plugin', label: 'Plugin' },
    { slug: 'publish', label: 'Publish' },
    { slug: 'seo', label: 'SEO' },
    { slug: 'how', label: 'How it works' },
    { slug: 'river', label: 'River' },
    { slug: 'docs', label: 'Docs' },
  ];
  return (
    <header className="site-header">
      <a className="brand" onClick={(e)=>{e.preventDefault(); onNavigate('home');}} href="#">
        {FAVICON}
        <span className="brand-name">Inkwell</span>
      </a>
      <nav className="nav">
        {items.map(i => (
          <a key={i.slug} href="#"
             className={route === i.slug ? 'active' : ''}
             onClick={(e)=>{e.preventDefault(); onNavigate(i.slug);}}>{i.label}</a>
        ))}
        <span className="kbd" onClick={onOpenPalette}>⌘ K</span>
      </nav>
    </header>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <span>inkwell.dev · v8 · MIT · built by Digid Inc.</span>
      <span>Fork it · Configure it · Let the agent run it</span>
    </footer>
  );
}

function Eyebrow({ children }) {
  return <div className="eyebrow">{children}</div>;
}

function Button({ variant='primary', children, ...props }) {
  return <button {...props} className={`btn btn-${variant}`}>{children}</button>;
}

// Network Hero — animated canvas per NetworkHero.tsx
function NetworkHero() {
  const ref = useRef(null);
  useEffect(() => {
    const canvas = ref.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); let raf;
    const COLORS = { agent:[212,160,23], tool:[6,182,212], topic:[16,185,129], lab:[167,139,250] };
    let W=0,H=0; const nodes=[];
    function resize(){ const dpr=window.devicePixelRatio||1; const r=canvas.getBoundingClientRect(); W=r.width; H=r.height; canvas.width=W*dpr; canvas.height=H*dpr; ctx.setTransform(dpr,0,0,dpr,0,0); }
    function init(){
      resize(); nodes.length=0;
      const clusters=[
        {x:0.2,y:0.4,t:'agent',n:6},{x:0.5,y:0.5,t:'topic',n:5},{x:0.8,y:0.4,t:'tool',n:5},
        {x:0.35,y:0.75,t:'lab',n:4},{x:0.65,y:0.25,t:'agent',n:3},{x:0.85,y:0.75,t:'topic',n:3},
      ];
      clusters.forEach(c=>{
        for(let i=0;i<c.n;i++){
          const a=Math.random()*Math.PI*2, d=Math.random()*Math.min(W,H)*0.12;
          nodes.push({x:c.x*W+Math.cos(a)*d,y:c.y*H+Math.sin(a)*d,vx:(Math.random()-.5)*.15,vy:(Math.random()-.5)*.15,r:1.5+Math.random()*2,t:c.t,p:Math.random()*Math.PI*2});
        }
      });
    }
    function draw(){
      ctx.clearRect(0,0,W,H);
      // edges
      for (let i=0;i<nodes.length;i++) for (let j=i+1;j<nodes.length;j++){
        const a=nodes[i],b=nodes[j]; const dx=a.x-b.x, dy=a.y-b.y; const d=Math.hypot(dx,dy);
        if (d<120){ ctx.strokeStyle=`rgba(255,255,255,${(1-d/120)*0.12})`; ctx.lineWidth=0.6; ctx.beginPath(); ctx.moveTo(a.x,a.y); ctx.lineTo(b.x,b.y); ctx.stroke(); }
      }
      nodes.forEach(n=>{
        n.x+=n.vx; n.y+=n.vy; n.p+=0.015;
        if(n.x<0||n.x>W) n.vx*=-1; if(n.y<0||n.y>H) n.vy*=-1;
        const [r,g,b]=COLORS[n.t]; const pulse=0.6+0.4*Math.sin(n.p);
        ctx.fillStyle=`rgba(${r},${g},${b},${0.55*pulse})`;
        ctx.beginPath(); ctx.arc(n.x,n.y,n.r*(1+pulse*0.3),0,Math.PI*2); ctx.fill();
      });
      raf=requestAnimationFrame(draw);
    }
    init(); draw();
    window.addEventListener('resize', init);
    return ()=>{ cancelAnimationFrame(raf); window.removeEventListener('resize', init); };
  }, []);
  return <canvas ref={ref} style={{position:'absolute', inset:0, width:'100%', height:'100%'}} />;
}

// Command Palette
function CommandPalette({ open, onClose, onNavigate }) {
  const [q, setQ] = useState('');
  const [sel, setSel] = useState(0);
  const items = [
    { t:'docs', title:'Getting Started', go:'docs' },
    { t:'docs', title:'Publishing — Agent Workflow', go:'docs' },
    { t:'blog', title:'Agent-powered publishing with Inkwell', go:'post' },
    { t:'blog', title:'Build your business on Inkwell', go:'post' },
    { t:'tool', title:'inkwell-publish', go:'docs' },
    { t:'labs', title:'Labs — Inkwell', go:'labs' },
  ];
  const results = items.filter(i => !q || i.title.toLowerCase().includes(q.toLowerCase())).slice(0,8);
  useEffect(()=>{ setSel(0); }, [q]);
  useEffect(()=>{
    function k(e){ if (e.key==='Escape') onClose(); }
    window.addEventListener('keydown',k); return ()=>window.removeEventListener('keydown',k);
  },[]);
  if (!open) return null;
  return (
    <div onClick={onClose} style={{position:'fixed',inset:0,zIndex:50,display:'flex',justifyContent:'center',paddingTop:'20vh'}}>
      <div style={{position:'absolute',inset:0,background:'rgba(0,0,0,0.6)'}}/>
      <div onClick={e=>e.stopPropagation()} style={{position:'relative',width:'100%',maxWidth:'32rem',background:'var(--ink-surface)',border:'1px solid var(--ink-border)',borderRadius:8,overflow:'hidden',boxShadow:'0 25px 50px -12px rgba(0,0,0,0.5)'}}>
        <input autoFocus value={q} onChange={e=>setQ(e.target.value)}
          placeholder="Search content..." style={{width:'100%',padding:'12px 16px',fontSize:14,background:'transparent',color:'var(--ink-text)',border:'none',outline:'none',borderBottom:'1px solid var(--ink-border)',boxSizing:'border-box'}}/>
        <ul style={{maxHeight:320,overflowY:'auto',padding:'8px 0',margin:0,listStyle:'none'}}>
          {results.map((it,i)=>(
            <li key={i}>
              <button onClick={()=>{onNavigate(it.go); onClose();}} onMouseEnter={()=>setSel(i)} style={{width:'100%',textAlign:'left',padding:'10px 16px',display:'flex',alignItems:'center',gap:12,cursor:'pointer',border:'none',background: i===sel?'rgba(255,255,255,0.06)':'transparent',borderLeft: i===sel?'2px solid var(--ink-primary)':'2px solid transparent'}}>
                <span style={{fontSize:10,textTransform:'uppercase',letterSpacing:'0.05em',padding:'2px 6px',borderRadius:4,background:'rgba(212,160,23,0.10)',color:'var(--ink-primary)',fontFamily:'var(--ink-font-mono)'}}>{it.t}</span>
                <span style={{fontSize:14,color:'var(--ink-text)'}}>{it.title}</span>
              </button>
            </li>
          ))}
          {results.length===0 && <li style={{padding:'24px 16px',textAlign:'center',color:'var(--ink-muted)',fontSize:14}}>No results found.</li>}
        </ul>
        <div style={{display:'flex',justifyContent:'space-between',padding:'8px 16px',fontSize:10,textTransform:'uppercase',letterSpacing:'0.05em',borderTop:'1px solid var(--ink-border)',color:'rgba(255,255,255,0.35)',fontFamily:'var(--ink-font-mono)'}}>
          <span>navigate with arrow keys</span><span>esc to close</span>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Header, Footer, Eyebrow, Button, NetworkHero, CommandPalette, FAVICON });
