// Inkwell — AI-first publishing & SEO thesis pages (v2)
const { useState, useEffect, useRef } = React;

// /publish — "publish while the insight is warm"
function PublishFromAnywhere() {
  const [activeAi, setActiveAi] = useState(0);
  const ais = [
    { name: 'Claude', color: '#D4A017', ic: 'C' },
    { name: 'ChatGPT', color: '#10B981', ic: 'G' },
    { name: 'Gemini', color: '#06B6D4', ic: 'G' },
    { name: 'Cursor', color: '#8B5CF6', ic: '⌘' },
  ];
  useEffect(() => {
    const t = setInterval(() => setActiveAi(a => (a + 1) % ais.length), 1400);
    return () => clearInterval(t);
  }, []);

  return (
    <div>
      <section style={{ padding: '64px 0 40px' }}>
        <Eyebrow>Publishing · warm-insight doctrine</Eyebrow>
        <h1 style={{ fontFamily: 'var(--ink-font-display)', fontSize: '3.25rem', fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1.02, margin: '14px 0 20px', maxWidth: 780 }}>
          Publish while the insight is warm.
        </h1>
        <p style={{ fontSize: 19, lineHeight: 1.55, color: 'var(--ink-muted)', margin: '0 0 36px', maxWidth: 640 }}>
          The moment right after you understand something is the moment it's most worth writing down. Inkwell connects directly to your AI — Claude, ChatGPT, Gemini, Cursor — so that insight goes from conversation to live post without the hour of cooling-off it takes to copy, reformat, and republish.
        </p>

        {/* AI sources → Inkwell */}
        <div style={{ background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 8, padding: '32px 28px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr) 80px 200px', alignItems: 'center', gap: 0 }}>
            <div style={{ gridColumn: '1 / 5', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
              {ais.map((a, i) => (
                <div key={a.name} style={{
                  padding: '16px 14px',
                  borderRadius: 6,
                  border: `1px solid ${activeAi === i ? a.color : 'var(--ink-border)'}`,
                  background: activeAi === i ? `${a.color}15` : 'var(--ink-bg)',
                  transition: 'all 400ms ease',
                  transform: activeAi === i ? 'translateY(-3px)' : 'none',
                  display: 'flex', alignItems: 'center', gap: 10,
                }}>
                  <div style={{ width: 28, height: 28, borderRadius: 4, background: a.color, color: '#0A0A10', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--ink-font-mono)', fontSize: 14, fontWeight: 700 }}>{a.ic}</div>
                  <div>
                    <div style={{ fontFamily: 'var(--ink-font-display)', fontSize: 13, fontWeight: 600, color: activeAi === i ? a.color : 'var(--ink-text)' }}>{a.name}</div>
                    <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-dim)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>mcp connected</div>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ textAlign: 'center', fontFamily: 'var(--ink-font-mono)', color: 'var(--ink-primary)', fontSize: 22 }}>→</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '16px 18px', border: '2px solid var(--ink-primary)', borderRadius: 6, background: 'rgba(212,160,23,0.10)' }}>
              <svg viewBox="0 0 128 128" width="26" height="26"><path fill="var(--ink-primary)" d="M50.4 78.5a75.1 75.1 0 0 0-28.5 6.9l24.2-65.7c.7-2 1.9-3.2 3.4-3.2h29c1.5 0 2.7 1.2 3.4 3.2l24.2 65.7s-11.6-7-28.5-7L67 45.5c-.4-1.7-1.6-2.8-2.9-2.8-1.3 0-2.5 1.1-2.9 2.7L50.4 78.5Z"/></svg>
              <div>
                <div style={{ fontFamily: 'var(--ink-font-display)', fontSize: 14, fontWeight: 700, color: 'var(--ink-primary)' }}>Your site. Live.</div>
                <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>cloudflare · ~12s</div>
              </div>
            </div>
          </div>
          <div style={{ marginTop: 20, paddingTop: 16, borderTop: '1px solid var(--ink-border)', fontFamily: 'var(--ink-font-mono)', fontSize: 11, color: 'var(--ink-muted)', textAlign: 'center', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
            one MCP server · every AI · zero tabs in between
          </div>
        </div>
      </section>

      <section style={{ padding: '36px 0', borderTop: '1px solid var(--ink-border)' }}>
        <Eyebrow>The warm-insight gap</Eyebrow>
        <h2 style={{ fontFamily: 'var(--ink-font-display)', fontSize: '1.75rem', fontWeight: 700, letterSpacing: '-0.02em', margin: '10px 0 20px' }}>
          Most thinking rots in a chat window.
        </h2>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
          <div>
            <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 11, color: 'var(--ink-danger)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>without inkwell</div>
            <div style={{ padding: '18px 20px', background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 6 }}>
              {[
                ['00:00', 'insight lands in Claude', 'warm'],
                ['00:12', 'you think "I should post this"', 'warm'],
                ['00:45', 'open Medium / LinkedIn / Ghost tab', 'cooling'],
                ['02:30', 'paste · reformat · re-upload images', 'cold'],
                ['08:00', 'invent title, excerpt, tags, slug', 'cold'],
                ['15:00', 'publish · or abandon', 'dead'],
              ].map(([t, e, s]) => (
                <div key={t} style={{ display: 'grid', gridTemplateColumns: '52px 1fr 80px', gap: 10, padding: '6px 0', fontSize: 13, color: 'var(--ink-muted)' }}>
                  <span style={{ fontFamily: 'var(--ink-font-mono)', color: 'var(--ink-dim)' }}>{t}</span>
                  <span>{e}</span>
                  <span style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, textTransform: 'uppercase', color: s === 'warm' ? 'var(--ink-accent)' : s === 'cooling' ? 'var(--ink-primary)' : s === 'cold' ? '#F59E0B' : 'var(--ink-danger)', textAlign: 'right' }}>{s}</span>
                </div>
              ))}
            </div>
          </div>
          <div>
            <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 11, color: 'var(--ink-accent)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>with inkwell</div>
            <div style={{ padding: '18px 20px', background: 'var(--ink-surface)', border: '1px solid var(--ink-primary)', borderRadius: 6 }}>
              {[
                ['00:00', 'insight lands in Claude', 'warm'],
                ['00:08', '"Claude, publish this as a blog post"', 'warm'],
                ['00:20', 'river validates, opens PR', 'warm'],
                ['00:32', 'live on your site', 'warm'],
                [null, null, null],
                [null, '↑ ~30 seconds. still warm.', null],
              ].map(([t, e, s], i) => e === null && i === 4 ? <div key={i} style={{ height: 24 }} /> : (
                <div key={i} style={{ display: 'grid', gridTemplateColumns: '52px 1fr 80px', gap: 10, padding: '6px 0', fontSize: 13, color: 'var(--ink-text)' }}>
                  <span style={{ fontFamily: 'var(--ink-font-mono)', color: 'var(--ink-dim)' }}>{t || ''}</span>
                  <span style={{ fontWeight: t ? 400 : 600, color: t ? 'var(--ink-text)' : 'var(--ink-primary)' }}>{e}</span>
                  <span style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, textTransform: 'uppercase', color: 'var(--ink-accent)', textAlign: 'right' }}>{s || ''}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section style={{ padding: '36px 0', borderTop: '1px solid var(--ink-border)' }}>
        <Eyebrow>What you actually say</Eyebrow>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, marginTop: 18 }}>
          {[
            ['"Publish our chat as a post under /publishing."', 'river drafts · you review · merge'],
            ['"Turn this thread into a docs page, link to the one on Zod."', 'wikilinks resolved automatically'],
            ['"Weekly digest: what did my site talk about this week?"', 'analytics + links back to posts'],
            ['"Update the pricing page with these three bullets."', 'PR opens, never pushed to main without you'],
          ].map(([q, a]) => (
            <div key={q} className="card" style={{ padding: '18px 20px' }}>
              <div style={{ fontFamily: 'var(--ink-font-body)', fontSize: 15, color: 'var(--ink-text)', fontStyle: 'italic', marginBottom: 10, lineHeight: 1.5 }}>{q}</div>
              <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 11, color: 'var(--ink-primary)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>→ {a}</div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

// /seo — inkwell's unfair SEO advantage
function SEOFirst() {
  const [checked, setChecked] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setChecked(c => (c < 9 ? c + 1 : c)), 380);
    return () => clearInterval(t);
  }, []);
  const checks = [
    ['Semantic HTML', 'Astro emits clean, crawlable HTML. No hydration soup.', 'technical'],
    ['LLMs.txt + sitemap.xml', 'Generated every build. AI crawlers know what you shipped.', 'AI-visibility'],
    ['JSON-LD per page', 'Article, BreadcrumbList, Organization, FAQ — typed by Zod, always valid.', 'technical'],
    ['Canonical wikilinks', '[[Post]] always resolves to one URL. Zero duplicate content.', 'on-page'],
    ['Backlinks graph', 'Every mention auto-surfaces on the linked post. Internal link equity ships free.', 'on-page'],
    ['Open Graph + Twitter cards', 'Frontmatter → meta tags. Previews look right everywhere.', 'social'],
    ['Edge-cached HTML', 'Cloudflare TTFB ~40ms warm. Core Web Vitals in the green by default.', 'technical'],
    ['Content-type aware schemas', 'Blog, docs, case studies each get the right schema.org type.', 'AI-visibility'],
    ['MDX image optimization', 'WebP + AVIF + responsive srcset. Zero config.', 'performance'],
  ];

  const catColor = {
    'technical': 'var(--ink-primary)',
    'AI-visibility': 'var(--ink-secondary)',
    'on-page': 'var(--ink-accent)',
    'social': '#8B5CF6',
    'performance': '#F59E0B',
  };

  return (
    <div>
      <section style={{ padding: '64px 0 24px' }}>
        <Eyebrow>SEO · no-brainer by construction</Eyebrow>
        <h1 style={{ fontFamily: 'var(--ink-font-display)', fontSize: '3rem', fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1.05, margin: '14px 0 18px', maxWidth: 780 }}>
          If Google and Claude can both read it, you win.
        </h1>
        <p style={{ fontSize: 18, lineHeight: 1.55, color: 'var(--ink-muted)', margin: '0 0 32px', maxWidth: 640 }}>
          SEO used to be a plugin you forgot to configure. With Inkwell it's the default output of the build — and it's tuned for the two audiences that matter now: search crawlers and AI retrieval.
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          {checks.map(([t, d, cat], i) => (
            <div key={t} style={{
              display: 'grid', gridTemplateColumns: '28px 1fr', gap: 14, padding: '16px 18px',
              background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 6,
              opacity: i < checked ? 1 : 0.35, transition: 'opacity 300ms ease',
            }}>
              <div style={{
                width: 22, height: 22, borderRadius: '50%',
                background: i < checked ? 'rgba(16,185,129,0.15)' : 'transparent',
                border: `1.5px solid ${i < checked ? 'var(--ink-accent)' : 'var(--ink-border)'}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: 'var(--ink-accent)', fontSize: 12, fontWeight: 700, fontFamily: 'var(--ink-font-mono)',
                marginTop: 2,
              }}>{i < checked ? '✓' : ''}</div>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
                  <span style={{ fontFamily: 'var(--ink-font-display)', fontSize: 14, fontWeight: 600, color: 'var(--ink-text)' }}>{t}</span>
                  <span style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.06em', padding: '2px 7px', borderRadius: 10, background: `${catColor[cat]}20`, color: catColor[cat] }}>{cat}</span>
                </div>
                <div style={{ fontSize: 13, color: 'var(--ink-muted)', lineHeight: 1.55 }}>{d}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* AI-visibility: the new SEO */}
      <section style={{ padding: '32px 0', borderTop: '1px solid var(--ink-border)' }}>
        <Eyebrow>The new traffic · AI retrieval</Eyebrow>
        <h2 style={{ fontFamily: 'var(--ink-font-display)', fontSize: '1.75rem', fontWeight: 700, letterSpacing: '-0.02em', margin: '10px 0 12px' }}>
          Google is one reader now. The other one is Claude.
        </h2>
        <p style={{ fontSize: 15, color: 'var(--ink-muted)', lineHeight: 1.6, maxWidth: 620, marginBottom: 24 }}>
          Inkwell ships an <code className="ink-code">/llms.txt</code> index of your whole corpus, clean semantic markup, and JSON-LD that AI crawlers actually parse. When someone asks Claude about your topic, your post is eligible to be cited.
        </p>

        <div style={{ background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 8, padding: '22px 24px', maxWidth: 720 }}>
          <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 11, color: 'var(--ink-dim)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>yourdomain.com/llms.txt</div>
          <pre style={{ margin: 0, fontFamily: 'var(--ink-font-mono)', fontSize: 13, lineHeight: 1.8, color: 'var(--ink-text)', overflow: 'auto' }}>
<span style={{ color: 'var(--ink-primary)' }}># Inkwell</span>{'\n'}<span style={{ color: 'var(--ink-muted)' }}>> Publish while the insight is warm. AI-first CMS.</span>{'\n\n'}<span style={{ color: 'var(--ink-secondary)' }}>## Core docs</span>{'\n'}- [Publishing]({'<url>'}/docs/publishing): ingest flow, MCP, frontmatter{'\n'}- [Configuration]({'<url>'}/docs/config): inkwell.config.ts reference{'\n'}- [River]({'<url>'}/river): the default ops agent{'\n\n'}<span style={{ color: 'var(--ink-secondary)' }}>## Optional</span>{'\n'}- [Build journal]({'<url>'}/blog): weekly posts on what shipped
          </pre>
        </div>
      </section>

      {/* SEO scorecard */}
      <section style={{ padding: '32px 0', borderTop: '1px solid var(--ink-border)' }}>
        <Eyebrow>Typical fork · out-of-the-box scores</Eyebrow>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginTop: 16 }}>
          {[
            ['100', 'Lighthouse SEO', 'median across 40 forks'],
            ['98', 'Performance', 'Cloudflare edge + preloaded fonts'],
            ['A', 'Schema.org validity', 'Zod-typed JSON-LD'],
            ['12', 'AI citations / post', 'median, 30 days after publish'],
          ].map(([v, l, sub]) => (
            <div key={l} className="card" style={{ padding: '18px 20px' }}>
              <div style={{ fontFamily: 'var(--ink-font-display)', fontSize: 36, fontWeight: 700, color: 'var(--ink-primary)', lineHeight: 1 }}>{v}</div>
              <div style={{ fontSize: 13, fontWeight: 600, marginTop: 10 }}>{l}</div>
              <div style={{ fontSize: 12, color: 'var(--ink-muted)', fontFamily: 'var(--ink-font-mono)', marginTop: 4 }}>{sub}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Frontmatter → schema preview */}
      <section style={{ padding: '32px 0 16px', borderTop: '1px solid var(--ink-border)' }}>
        <Eyebrow>What you write → what crawlers see</Eyebrow>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 16 }}>
          <div>
            <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 11, color: 'var(--ink-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>you write (frontmatter)</div>
            <pre style={{ margin: 0, padding: '14px 16px', background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 6, fontFamily: 'var(--ink-font-mono)', fontSize: 12, lineHeight: 1.7, overflow: 'auto', color: 'var(--ink-text)' }}>
{`---
title: "Publish while it's warm"
pillar: publishing
published: 2026-04-17
tags: [mcp, seo]
canonical: /publishing-warm
---`}
            </pre>
          </div>
          <div>
            <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 11, color: 'var(--ink-primary)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>inkwell emits (schema.org)</div>
            <pre style={{ margin: 0, padding: '14px 16px', background: 'var(--ink-surface)', border: '1px solid var(--ink-primary)', borderRadius: 6, fontFamily: 'var(--ink-font-mono)', fontSize: 12, lineHeight: 1.7, overflow: 'auto', color: 'var(--ink-text)' }}>
{`{
  "@type": "Article",
  "headline": "Publish while it's warm",
  "datePublished": "2026-04-17",
  "author": { "@type": "Person", "name": "Mumega" },
  "publisher": { "@type": "Organization", "name": "Inkwell" },
  "keywords": ["mcp", "seo"]
}`}
            </pre>
          </div>
        </div>
      </section>
    </div>
  );
}

Object.assign(window, { PublishFromAnywhere, SEOFirst });
