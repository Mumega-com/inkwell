// Inkwell site — page screens
const { useState, useEffect } = React;

function Home({ onNavigate }) {
  return (
    <div>
      <section style={{position:'relative', padding:'72px 0 80px', overflow:'hidden'}}>
        <NetworkHero/>
        <div style={{position:'relative', maxWidth:680, zIndex:2}}>
          <Eyebrow>Forkable SaaS framework · v8 · agent-operated</Eyebrow>
          <h1 style={{fontFamily:'var(--ink-font-display)',fontSize:'3.25rem',fontWeight:700,letterSpacing:'-0.02em',lineHeight:1.05,margin:'14px 0 18px'}}>
            The business operating system.
          </h1>
          <p style={{fontSize:19,lineHeight:1.55,color:'var(--ink-muted)',margin:'0 0 28px',maxWidth:580}}>
            <code className="ink-code">npx create-inkwell my-site</code> — edit one config, deploy. 24 plugins, 14 ports, 16 MCP tools. Content engine, business dashboard, commerce, auth, contracts, courses, analytics, media — operated by your AI.
          </p>
          <div style={{display:'flex',gap:12}}>
            <Button onClick={()=>onNavigate('publish')}>See the publish flow →</Button>
            <Button variant="ghost" onClick={()=>onNavigate('how')}>How it works</Button>
          </div>
        </div>
      </section>

      <section style={{padding:'32px 0 48px', borderTop:'1px solid var(--ink-border)'}}>
        <Eyebrow>Five pillars</Eyebrow>
        <div style={{display:'grid',gridTemplateColumns:'repeat(5, 1fr)',gap:14,marginTop:18}}>
          {[
            ['Vision','Where Inkwell is headed — roadmap, principles, provocations.'],
            ['Publishing','Markdown in, site out. Wikilinks and backlinks for free.'],
            ['Technology','Astro + React islands. Typed content. No SaaS dependency.'],
            ['People','The team, the agents, the contributors.'],
            ['Examples','Real forks running real businesses.'],
          ].map(([t,d])=>(
            <div key={t} className="card">
              <div style={{fontFamily:'var(--ink-font-display)',fontSize:14,fontWeight:600,color:'var(--ink-primary)',marginBottom:6}}>{t}</div>
              <div style={{fontSize:13,lineHeight:1.55,color:'var(--ink-muted)'}}>{d}</div>
            </div>
          ))}
        </div>
      </section>

      <section style={{padding:'32px 0 16px', borderTop:'1px solid var(--ink-border)'}}>
        <Eyebrow>Recent posts</Eyebrow>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14,marginTop:16}}>
          {[
            ['APR 17','Agent-powered publishing with Inkwell','How the ingest script moves markdown from inbox to collection and validates Zod frontmatter on the way in.'],
            ['APR 10','The flywheel is online','Daily analytics → gaps → posts → reactions → more analytics. A closed loop the agent can steer.'],
            ['APR 02','Why Inkwell is dark by default','On JetBrains Mono headings, ink gold, and the small joy of a restrained palette.'],
            ['MAR 28','MCP server, 1.0','Seven tools, all documented. Claude can publish, search, analyze, and reply.'],
          ].map(([d,t,e])=>(
            <a href="#" onClick={(ev)=>{ev.preventDefault(); onNavigate('post');}} key={t} className="card" style={{display:'block',textDecoration:'none',color:'inherit',cursor:'pointer'}}>
              <div style={{fontFamily:'var(--ink-font-mono)',fontSize:11,color:'var(--ink-muted)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:8}}>{d}</div>
              <div style={{fontFamily:'var(--ink-font-display)',fontSize:17,fontWeight:600,lineHeight:1.3,marginBottom:6}}>{t}</div>
              <div style={{fontSize:13,color:'var(--ink-muted)',lineHeight:1.55}}>{e}</div>
            </a>
          ))}
        </div>
      </section>

      <section style={{padding:'36px 0 8px'}}>
        <div style={{border:'2px solid var(--ink-primary)',borderRadius:8,padding:'22px 24px',display:'flex',alignItems:'center',justifyContent:'space-between',gap:24}}>
          <div>
            <div style={{fontFamily:'var(--ink-font-display)',fontSize:18,fontWeight:600,marginBottom:4}}>Subscribe to the build journal.</div>
            <div style={{fontSize:13,color:'var(--ink-muted)'}}>Weekly. No spam, no tracking. Unsub with one click.</div>
          </div>
          <div style={{display:'flex',gap:8}}>
            <input placeholder="you@email.com" style={{padding:'10px 12px',borderRadius:4,background:'var(--ink-bg)',border:'1px solid var(--ink-border)',color:'var(--ink-text)',fontSize:14,minWidth:240}}/>
            <Button>Subscribe</Button>
          </div>
        </div>
      </section>
    </div>
  );
}

function Blog({ onNavigate }) {
  const posts = [
    ['APR 17','Agent-powered publishing with Inkwell','publishing'],
    ['APR 10','The flywheel is online','vision'],
    ['APR 02','Why Inkwell is dark by default','technology'],
    ['MAR 28','MCP server, 1.0','technology'],
    ['MAR 22','Building Viamar on an Inkwell fork','examples'],
    ['MAR 18','What I ship, what the agent ships','people'],
    ['MAR 12','The 9am telegram','publishing'],
    ['MAR 04','Zod frontmatter, one year in','technology'],
  ];
  return (
    <section style={{padding:'44px 0 24px'}}>
      <Eyebrow>Build journal</Eyebrow>
      <h1 style={{fontFamily:'var(--ink-font-display)',fontSize:'2.25rem',fontWeight:700,letterSpacing:'-0.02em',margin:'8px 0 28px'}}>Writing what Inkwell ships.</h1>
      <div style={{display:'flex',flexDirection:'column',gap:12}}>
        {posts.map(([d,t,tag],i)=>(
          <a href="#" key={i} onClick={(e)=>{e.preventDefault(); onNavigate('post');}} style={{display:'flex',alignItems:'baseline',justifyContent:'space-between',gap:16,padding:'14px 0',borderBottom:'1px solid var(--ink-border)',textDecoration:'none',color:'inherit'}}>
            <div style={{display:'flex',alignItems:'baseline',gap:16}}>
              <span style={{fontFamily:'var(--ink-font-mono)',fontSize:11,color:'var(--ink-dim)',minWidth:52,textTransform:'uppercase'}}>{d}</span>
              <span style={{fontFamily:'var(--ink-font-display)',fontSize:17,fontWeight:600,color:'var(--ink-text)'}}>{t}</span>
            </div>
            <span style={{fontFamily:'var(--ink-font-mono)',fontSize:10,textTransform:'uppercase',letterSpacing:'0.05em',padding:'3px 8px',borderRadius:4,background:'rgba(212,160,23,0.10)',color:'var(--ink-primary)'}}>{tag}</span>
          </a>
        ))}
      </div>
    </section>
  );
}

function Post() {
  const [progress, setProgress] = useState(0);
  const [reactions, setReactions] = useState({ '🔥':12,'❤️':8,'🧠':3,'👏':0,'🚀':5 });
  const [mine, setMine] = useState({});
  useEffect(()=>{
    function onScroll(){
      const el = document.querySelector('.post-scroll');
      if (!el) return;
      const top = el.scrollTop, h = el.scrollHeight - el.clientHeight;
      setProgress(h>0 ? top/h : 0);
    }
    const el = document.querySelector('.post-scroll');
    if (el) el.addEventListener('scroll', onScroll);
    return ()=>{ if (el) el.removeEventListener('scroll', onScroll); };
  },[]);
  function react(e){
    setReactions(r=>({...r, [e]: r[e] + (mine[e]?-1:1)}));
    setMine(m=>({...m, [e]: !m[e]}));
  }
  return (
    <div style={{position:'relative'}}>
      <div className="ink-progress" style={{width:`${progress*100}%`,position:'fixed',top:0}}/>
      <div className="post-scroll" style={{display:'grid',gridTemplateColumns:'1fr 220px',gap:48,paddingTop:40,maxHeight:'calc(100vh - 80px)',overflowY:'auto'}}>
        <article>
          <Eyebrow>Publishing · APR 17, 2026</Eyebrow>
          <h1 style={{fontFamily:'var(--ink-font-display)',fontSize:'2.25rem',fontWeight:700,letterSpacing:'-0.02em',margin:'10px 0 12px',lineHeight:1.15}}>Agent-powered publishing with Inkwell</h1>
          <div style={{display:'flex',gap:12,alignItems:'center',margin:'0 0 20px',flexWrap:'wrap',fontFamily:'var(--ink-font-mono)',fontSize:11,color:'var(--ink-muted)'}}>
            <span>written by <span style={{color:'var(--ink-text)'}}>Mumega</span></span>
            <span>·</span>
            <span>published via <span style={{color:'var(--ink-secondary)'}}>mcp://inkwell.publish</span></span>
            <span>·</span>
            <span>shipped by <span style={{color:'var(--ink-primary)'}}>river</span></span>
            <span>·</span>
            <span>6 min read</span>
          </div>
          <p style={{fontSize:18,lineHeight:1.6,color:'var(--ink-muted)',margin:'0 0 26px'}}>
            Drop markdown in <code className="ink-code">content/inbox/</code>, run <code className="ink-code">npm run publish</code>, and the ingest script moves the file into the right collection with a Zod-validated frontmatter pass.
          </p>
          <h2 id="s1" style={{fontFamily:'var(--ink-font-display)',fontSize:'1.75rem',fontWeight:700,margin:'32px 0 12px',letterSpacing:'-0.02em'}}>The ingest script</h2>
          <p style={{fontSize:16,lineHeight:1.8,color:'var(--ink-text)',margin:'0 0 14px',maxWidth:620}}>
            The script walks the inbox, infers the collection from folder name, runs the file's frontmatter through a typed Zod schema, and commits the move. If validation fails, the file stays put and a clear error points at the offending field.
          </p>
          <h2 id="s2" style={{fontFamily:'var(--ink-font-display)',fontSize:'1.75rem',fontWeight:700,margin:'32px 0 12px',letterSpacing:'-0.02em'}}>Wikilinks and backlinks</h2>
          <p style={{fontSize:16,lineHeight:1.8,color:'var(--ink-text)',margin:'0 0 14px',maxWidth:620}}>
            Any <code className="ink-code">[[Post Title]]</code> resolves against the collection index at build. The backlinks graph is regenerated in the same pass, so a new page automatically appears under "Mentioned in" on every post that links to it.
          </p>
          <blockquote style={{borderLeft:'3px solid var(--ink-primary)',padding:'2px 0 2px 16px',margin:'20px 0',color:'var(--ink-muted)',fontStyle:'italic',fontSize:15,lineHeight:1.6}}>
            Voice: builder, not marketer. Every claim is backed by something the site can actually show.
          </blockquote>
          <h2 id="s3" style={{fontFamily:'var(--ink-font-display)',fontSize:'1.75rem',fontWeight:700,margin:'32px 0 12px',letterSpacing:'-0.02em'}}>What's next</h2>
          <p style={{fontSize:16,lineHeight:1.8,color:'var(--ink-text)',margin:'0 0 14px',maxWidth:620}}>
            v4 brings the dashboard online. The same config powers contracts, payments, and the chat widget — one file, every surface.
          </p>
          {/* Reactions */}
          <div style={{marginTop:36, paddingTop:20, borderTop:'1px solid var(--ink-border)'}}>
            <div className="eyebrow" style={{marginBottom:10}}>React</div>
            <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
              {Object.entries(reactions).map(([e,n])=>(
                <button key={e} onClick={()=>react(e)} style={{display:'inline-flex',alignItems:'center',gap:6,padding:'6px 12px',borderRadius:9999,border:`1px solid ${mine[e]?'var(--ink-primary)':'var(--ink-border)'}`,background:mine[e]?'rgba(212,160,23,0.10)':'var(--ink-surface)',cursor:'pointer',fontSize:14}}>
                  <span>{e}</span>
                  {n>0 && <span style={{fontFamily:'var(--ink-font-mono)',fontSize:12,color:mine[e]?'var(--ink-primary)':'var(--ink-muted)'}}>{n}</span>}
                </button>
              ))}
            </div>
          </div>
        </article>
        <aside style={{position:'sticky',top:0,alignSelf:'start'}}>
          <div className="eyebrow" style={{marginBottom:12}}>On this page</div>
          <div style={{display:'flex',flexDirection:'column',gap:8}}>
            <a href="#s1" style={{fontSize:13,color:'var(--ink-muted)',textDecoration:'none',paddingLeft:8,borderLeft:'2px solid var(--ink-primary)'}}>The ingest script</a>
            <a href="#s2" style={{fontSize:13,color:'var(--ink-muted)',textDecoration:'none',paddingLeft:8,borderLeft:'2px solid var(--ink-border)'}}>Wikilinks and backlinks</a>
            <a href="#s3" style={{fontSize:13,color:'var(--ink-muted)',textDecoration:'none',paddingLeft:8,borderLeft:'2px solid var(--ink-border)'}}>What's next</a>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Docs({ onNavigate }) {
  const nav = [
    ['Getting Started', ['Overview','Install','First publish','Configuration']],
    ['Content', ['Collections','Frontmatter','Wikilinks','Backlinks']],
    ['Agent', ['Mandates','MCP tools','Daily flywheel','Telegram steering']],
    ['Deployment', ['Cloudflare Pages','Astro build']],
  ];
  return (
    <section style={{padding:'36px 0', display:'grid',gridTemplateColumns:'220px 1fr',gap:40}}>
      <nav style={{borderRight:'1px solid var(--ink-border)',paddingRight:16}}>
        {nav.map(([group, items])=>(
          <div key={group} style={{marginBottom:22}}>
            <div className="eyebrow" style={{marginBottom:8}}>{group}</div>
            <ul style={{listStyle:'none',padding:0,margin:0,display:'flex',flexDirection:'column',gap:6}}>
              {items.map((i,idx)=>(
                <li key={i}><a href="#" style={{fontSize:13,color: (group==='Getting Started' && idx===0)?'var(--ink-primary)':'var(--ink-muted)',textDecoration:'none'}}>{i}</a></li>
              ))}
            </ul>
          </div>
        ))}
      </nav>
      <article style={{maxWidth:680}}>
        <Eyebrow>Getting Started</Eyebrow>
        <h1 style={{fontFamily:'var(--ink-font-display)',fontSize:'2rem',fontWeight:700,letterSpacing:'-0.02em',margin:'8px 0 12px'}}>Overview</h1>
        <p style={{fontSize:17,lineHeight:1.6,color:'var(--ink-muted)',margin:'0 0 20px'}}>Inkwell is a CMS that treats agents as first-class authors. One config drives every surface — marketing site, blog, docs, dashboard, chat, and the MCP server the agent connects through.</p>

        <h2 style={{fontFamily:'var(--ink-font-display)',fontSize:'1.5rem',fontWeight:700,margin:'28px 0 10px'}}>Install</h2>
        <pre style={{background:'var(--ink-surface)',border:'1px solid var(--ink-border)',borderRadius:6,padding:'12px 14px',fontFamily:'var(--ink-font-mono)',fontSize:13,color:'var(--ink-text)',overflow:'auto',margin:'0 0 16px'}}>
<code>git clone https://github.com/Mumega-com/inkwell.git{'\n'}cd inkwell && npm install{'\n'}npm run dev</code>
        </pre>

        <h2 style={{fontFamily:'var(--ink-font-display)',fontSize:'1.5rem',fontWeight:700,margin:'28px 0 10px'}}>First publish</h2>
        <p style={{fontSize:16,lineHeight:1.8,color:'var(--ink-text)',margin:'0 0 14px'}}>Drop markdown in <code className="ink-code">content/inbox/</code> and run <code className="ink-code">npm run publish</code>. The ingest script validates, moves, and rebuilds the backlinks graph in a single pass.</p>

        <div style={{border:'1px solid var(--ink-border)',borderRadius:6,padding:'14px 16px',marginTop:24,display:'flex',gap:14,alignItems:'center'}}>
          <div style={{fontFamily:'var(--ink-font-mono)',fontSize:11,textTransform:'uppercase',color:'var(--ink-primary)',letterSpacing:'0.05em'}}>Note</div>
          <div style={{fontSize:14,color:'var(--ink-muted)'}}>The dashboard and chat surfaces require a Cloudflare Pages deployment with the MCP adapter — see <a href="#" style={{color:'var(--ink-primary)',textDecoration:'none'}}>Deployment</a>.</div>
        </div>
      </article>
    </section>
  );
}

function Labs({ onNavigate }) {
  const items = [
    ['Backlinks graph','Interactive force-layout of every wikilink in the corpus. Click a node, read the post.'],
    ['Agent console','Live tail of the agent\'s decisions. What it read, what it wrote, why.'],
    ['Frontmatter inspector','Click any page in the site, see the typed frontmatter and lint results.'],
    ['Flywheel viewer','The closed loop: analytics → gaps → posts → reactions. Rendered as a sankey.'],
  ];
  return (
    <section style={{padding:'44px 0'}}>
      <Eyebrow>Labs · experiments</Eyebrow>
      <h1 style={{fontFamily:'var(--ink-font-display)',fontSize:'2.25rem',fontWeight:700,letterSpacing:'-0.02em',margin:'8px 0 10px'}}>Work in progress.</h1>
      <p style={{fontSize:17,color:'var(--ink-muted)',lineHeight:1.55,margin:'0 0 28px',maxWidth:560}}>
        Things Inkwell is building but hasn't shipped. Poke around; some will land in v4, others won't.
      </p>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
        {items.map(([t,d])=>(
          <div key={t} className="card" style={{cursor:'pointer'}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'baseline',marginBottom:8}}>
              <div style={{fontFamily:'var(--ink-font-display)',fontSize:16,fontWeight:600}}>{t}</div>
              <span style={{fontFamily:'var(--ink-font-mono)',fontSize:10,textTransform:'uppercase',letterSpacing:'0.05em',padding:'3px 8px',borderRadius:12,background:'rgba(212,160,23,0.15)',color:'var(--ink-primary)'}}>alpha</span>
            </div>
            <div style={{fontSize:13,color:'var(--ink-muted)',lineHeight:1.55}}>{d}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Team() {
  return (
    <section style={{padding:'44px 0'}}>
      <Eyebrow>Team · the agents and the humans</Eyebrow>
      <h1 style={{fontFamily:'var(--ink-font-display)',fontSize:'2.25rem',fontWeight:700,letterSpacing:'-0.02em',margin:'8px 0 28px'}}>Everyone who pushes to main.</h1>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
        {[
          ['Mumega','Human','Founder. Writes the roadmap, shapes the voice, reviews the PRs.'],
          ['inkwell-web','Agent','Publishes the site. Runs the flywheel. Steers from telegram.'],
          ['inkwell-ops','Agent','Runs the dashboard. Watches contracts, payments, the chat widget.'],
          ['Contributors','Human · 4','Forkers who sent patches back upstream.'],
        ].map(([n,role,d])=>(
          <div key={n} className="card" style={{display:'flex',gap:14,alignItems:'flex-start'}}>
            <div style={{width:44,height:44,borderRadius:6,background:role==='Agent'?'rgba(212,160,23,0.15)':'rgba(6,182,212,0.15)',color:role==='Agent'?'var(--ink-primary)':'var(--ink-secondary)',display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'var(--ink-font-mono)',fontSize:15,fontWeight:700,flexShrink:0}}>{n[0]}</div>
            <div>
              <div style={{display:'flex',alignItems:'baseline',gap:10,marginBottom:4}}>
                <span style={{fontFamily:'var(--ink-font-display)',fontSize:15,fontWeight:600}}>{n}</span>
                <span style={{fontFamily:'var(--ink-font-mono)',fontSize:10,textTransform:'uppercase',color:role==='Agent'?'var(--ink-primary)':'var(--ink-secondary)',letterSpacing:'0.05em'}}>{role}</span>
              </div>
              <div style={{fontSize:13,color:'var(--ink-muted)',lineHeight:1.55}}>{d}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

Object.assign(window, { Home, Blog, Post, Docs, Labs, Team });
