// Inkwell — Plugin detail page template.
// Reference implementation: the `content` plugin.
// Surfaces every field of PluginManifest + ports + config keys.
const { useState: useStateP, useMemo: useMemoP } = React;

// Full plugin registry with every field the detail page needs.
const PLUGIN_REGISTRY = {
  content: {
    name: 'content', icon: '✎', color: 'var(--ink-primary)', kind: 'core', version: '5.2.0',
    role: 'viewer',
    desc: 'Ingest, validate, and publish markdown. Wikilinks, backlinks, RSS, sitemap, llms.txt.',
    routes: [
      ['GET',  '/api/posts',               'list posts by pillar, tag, pagination'],
      ['GET',  '/api/posts/:slug',         'single post + resolved backlinks'],
      ['POST', '/api/publish',             'ingest markdown → validate → open PR'],
      ['POST', '/api/drafts',              'draft without publish'],
    ],
    tools: [
      ['publish_content', 'Draft → validate → open PR. Only merges with human review.',
        `{
  pillar: "publishing" | "technology" | "vision" | ...,
  title: string,
  body: string,  // markdown with [[wikilinks]]
  tags?: string[],
  canonical?: string
}`],
      ['list_posts', 'List published posts, newest first. Filter by pillar or tag.',
        `{
  pillar?: string,
  tag?: string,
  limit?: number  // default 20
}`],
    ],
    widgets: [
      ['RecentPosts', 'Dashboard card: 5 most-recent posts with view counts.'],
    ],
    migrations: ['0001_posts.sql', '0002_backlinks_idx.sql', '0003_llms_txt_cache.sql'],
    configKeys: [
      ['content.pillars',          'string[]',          'Allowed pillar slugs. Enforced by Zod on ingest.'],
      ['content.defaultPillar',    'string',            'Fallback when frontmatter omits pillar.'],
      ['content.inboxDir',         'path',              'Where the ingest script looks for new markdown.'],
      ['seo.organization.name',    'string',            'Used in JSON-LD publisher on every article.'],
      ['seo.defaultAuthor.name',   'string',            'Author fallback in frontmatter.'],
    ],
    ports: ['database', 'search'],
    events: [
      ['content.published',  'emitted after a post merges to main'],
      ['content.unpublished','emitted when a post moves to archive'],
    ],
    frontmatter: `---
title: "Publish while it's warm"
pillar: publishing
published: 2026-04-17
tags: [mcp, seo]
canonical: /publishing-warm
---`,
  },
  contracts: {
    name: 'contracts', icon: '§', color: 'var(--ink-secondary)', kind: 'business', version: '5.2.0',
    role: 'manager',
    desc: 'E-signature portal, insurance selection, 9-step shipment tracking, Twilio SMS + Resend email.',
    routes: [
      ['POST', '/api/contracts',             'create contract · returns shareable link'],
      ['GET',  '/api/contracts/:id',         'fetch by public token'],
      ['POST', '/api/contracts/:id/sign',    'submit e-signature + insurance choice'],
      ['GET',  '/api/contracts/:id/events',  'tracking timeline (9 stages)'],
      ['POST', '/api/contracts/:id/events',  'append tracking event'],
      ['POST', '/api/contracts/:id/notify',  'trigger SMS + email re-send'],
    ],
    tools: [],
    widgets: [['ActiveContracts', 'Dashboard card: in-flight contracts by stage.']],
    migrations: ['0001_contracts.sql', '0002_contract_events.sql', '0003_signatures.sql'],
    configKeys: [
      ['contracts.insuranceTiers', 'enum[]',   'all_risk | total_loss | decline'],
      ['contracts.stages',         'string[]', 'Custom 9-step timeline labels.'],
      ['notifications.sms.from',   'string',   'Twilio number used for contract SMS.'],
    ],
    ports: ['database', 'auth'],
    events: [
      ['contract.signed',    'counterparty e-signed the agreement'],
      ['contract.stage.advanced', 'tracking event appended'],
    ],
    frontmatter: null,
  },
};

const PLUGIN_LIST = Object.keys(PLUGIN_REGISTRY);

const ROLE_TONE = {
  viewer: 'var(--ink-dim)', member: 'var(--ink-muted)',
  manager: 'var(--ink-secondary)', admin: 'var(--ink-primary)', owner: 'var(--ink-accent)',
};

function PluginDetail({ onNavigate }) {
  const [slug, setSlug] = useStateP('content');
  const [tab, setTab] = useStateP('routes');
  const p = PLUGIN_REGISTRY[slug];

  const tabs = useMemoP(() => ([
    ['routes',      `Routes · ${p.routes.length}`],
    ['tools',       `MCP Tools · ${p.tools.length}`],
    ['widgets',     `Widgets · ${p.widgets.length}`],
    ['config',      `Config · ${p.configKeys.length}`],
    ['ports',       `Ports · ${p.ports.length}`],
    ['migrations',  `Migrations · ${p.migrations.length}`],
    ['events',      `Events · ${p.events.length}`],
  ]), [slug]);

  return (
    <div>
      {/* Breadcrumb + picker */}
      <section style={{ padding: '48px 0 16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontFamily: 'var(--ink-font-mono)', fontSize: 11, color: 'var(--ink-dim)', marginBottom: 22, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
          <a href="#" onClick={(e)=>{e.preventDefault(); onNavigate('architecture');}} style={{ color: 'var(--ink-muted)' }}>architecture</a>
          <span>/</span>
          <span>plugins</span>
          <span>/</span>
          <span style={{ color: p.color }}>{slug}</span>
        </div>

        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 20 }}>
          {PLUGIN_LIST.map(k => {
            const pp = PLUGIN_REGISTRY[k];
            const on = slug === k;
            return (
              <button key={k} onClick={() => { setSlug(k); setTab('routes'); }} style={{
                display: 'flex', alignItems: 'center', gap: 6,
                padding: '6px 12px',
                background: on ? `${pp.color}18` : 'transparent',
                border: `1px solid ${on ? pp.color : 'var(--ink-border)'}`,
                color: on ? pp.color : 'var(--ink-muted)',
                borderRadius: 4, fontFamily: 'var(--ink-font-mono)', fontSize: 11, cursor: 'pointer',
              }}>
                <span style={{ color: pp.color }}>{pp.icon}</span>{pp.name}
              </button>
            );
          })}
          <div style={{ padding: '6px 12px', fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-dim)', fontStyle: 'italic' }}>
            (+ 10 more — template covers all)
          </div>
        </div>

        {/* Plugin header card */}
        <div style={{ background: 'var(--ink-surface)', border: `1px solid ${p.color}`, borderRadius: 8, padding: '24px 26px', display: 'grid', gridTemplateColumns: '64px 1fr auto', gap: 22, alignItems: 'center' }}>
          <div style={{ width: 56, height: 56, borderRadius: 8, background: `${p.color}18`, border: `1px solid ${p.color}`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: p.color, fontSize: 28 }}>{p.icon}</div>
          <div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginBottom: 4 }}>
              <h1 style={{ fontFamily: 'var(--ink-font-display)', fontSize: '2rem', fontWeight: 700, letterSpacing: '-0.02em', margin: 0 }}>{p.name}</h1>
              <span style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 12, color: 'var(--ink-dim)' }}>v{p.version}</span>
              <span style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, padding: '2px 8px', borderRadius: 10, background: `${p.color}20`, color: p.color, textTransform: 'uppercase', letterSpacing: '0.08em' }}>{p.kind}</span>
            </div>
            <div style={{ fontSize: 15, color: 'var(--ink-muted)', lineHeight: 1.55 }}>{p.desc}</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-dim)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 4 }}>required role</div>
            <div style={{ fontFamily: 'var(--ink-font-display)', fontSize: 16, fontWeight: 600, color: ROLE_TONE[p.role] }}>{p.role}</div>
          </div>
        </div>

        {/* Quick stats strip */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 0, marginTop: 14, border: '1px solid var(--ink-border)', borderRadius: 6, overflow: 'hidden', background: 'var(--ink-surface)' }}>
          {[
            ['routes', p.routes.length],
            ['mcp tools', p.tools.length],
            ['widgets', p.widgets.length],
            ['config keys', p.configKeys.length],
            ['ports', p.ports.length],
            ['migrations', p.migrations.length],
            ['events', p.events.length],
          ].map(([l, v], i) => (
            <div key={l} style={{ padding: '14px 16px', borderRight: i < 6 ? '1px solid var(--ink-border)' : 0, textAlign: 'center' }}>
              <div style={{ fontFamily: 'var(--ink-font-display)', fontSize: 22, fontWeight: 700, color: v > 0 ? p.color : 'var(--ink-dim)' }}>{v}</div>
              <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 9, color: 'var(--ink-dim)', textTransform: 'uppercase', letterSpacing: '0.08em', marginTop: 2 }}>{l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Tabs */}
      <section style={{ padding: '16px 0 0', borderTop: '1px solid var(--ink-border)' }}>
        <div style={{ display: 'flex', gap: 2, borderBottom: '1px solid var(--ink-border)', marginBottom: 20, overflow: 'auto' }}>
          {tabs.map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)} style={{
              background: 'transparent', border: 0, padding: '10px 14px',
              fontFamily: 'var(--ink-font-display)', fontSize: 12, fontWeight: 600,
              color: tab === k ? p.color : 'var(--ink-muted)',
              borderBottom: `2px solid ${tab === k ? p.color : 'transparent'}`,
              marginBottom: -1, cursor: 'pointer', whiteSpace: 'nowrap',
            }}>{l}</button>
          ))}
        </div>

        {tab === 'routes' && (
          <div style={{ background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 6 }}>
            {p.routes.length === 0 ? <Empty label="No routes mounted." /> : p.routes.map(([m, path, desc], i) => (
              <div key={path} style={{ display: 'grid', gridTemplateColumns: '70px 260px 1fr', gap: 14, padding: '12px 18px', borderTop: i > 0 ? '1px solid var(--ink-border)' : 0, alignItems: 'center' }}>
                <span style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, padding: '3px 8px', borderRadius: 3, background: `${p.color}20`, color: p.color, textAlign: 'center', fontWeight: 700, letterSpacing: '0.05em' }}>{m}</span>
                <code style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 12, color: 'var(--ink-text)' }}>{path}</code>
                <span style={{ fontSize: 13, color: 'var(--ink-muted)' }}>{desc}</span>
              </div>
            ))}
          </div>
        )}

        {tab === 'tools' && (
          <div style={{ display: 'grid', gap: 14 }}>
            {p.tools.length === 0 ? <Empty label="This plugin registers no MCP tools." /> : p.tools.map(([name, desc, schema]) => (
              <div key={name} style={{ background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 6, padding: '16px 20px' }}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 6 }}>
                  <code style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 14, fontWeight: 700, color: p.color }}>{name}</code>
                  <span style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-dim)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>mcp tool</span>
                </div>
                <div style={{ fontSize: 13, color: 'var(--ink-muted)', lineHeight: 1.55, marginBottom: 12 }}>{desc}</div>
                <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-dim)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>input schema</div>
                <pre style={{ margin: 0, padding: '12px 14px', background: '#0A0A10', border: '1px solid var(--ink-border)', borderRadius: 4, fontFamily: 'var(--ink-font-mono)', fontSize: 11.5, lineHeight: 1.7, color: 'var(--ink-text)', overflow: 'auto' }}>{schema}</pre>
              </div>
            ))}
          </div>
        )}

        {tab === 'widgets' && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 14 }}>
            {p.widgets.length === 0 ? <Empty label="No dashboard widgets." /> : p.widgets.map(([name, desc]) => (
              <div key={name} className="card" style={{ padding: '16px 18px' }}>
                <div style={{ fontFamily: 'var(--ink-font-display)', fontSize: 14, fontWeight: 600, color: p.color, marginBottom: 4 }}>&lt;{name} /&gt;</div>
                <div style={{ fontSize: 13, color: 'var(--ink-muted)', lineHeight: 1.55 }}>{desc}</div>
                <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-dim)', textTransform: 'uppercase', letterSpacing: '0.06em', marginTop: 8 }}>registered via manifest.dashboardWidgets</div>
              </div>
            ))}
          </div>
        )}

        {tab === 'config' && (
          <div style={{ background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 6 }}>
            {p.configKeys.map(([k, t, d], i) => (
              <div key={k} style={{ display: 'grid', gridTemplateColumns: '260px 120px 1fr', gap: 14, padding: '12px 18px', borderTop: i > 0 ? '1px solid var(--ink-border)' : 0, alignItems: 'center' }}>
                <code style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 12, color: 'var(--ink-text)' }}>{k}</code>
                <span style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-secondary)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{t}</span>
                <span style={{ fontSize: 13, color: 'var(--ink-muted)', lineHeight: 1.55 }}>{d}</span>
              </div>
            ))}
          </div>
        )}

        {tab === 'ports' && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 14 }}>
            {p.ports.map(port => (
              <div key={port} className="card" style={{ padding: '18px 20px', borderColor: 'var(--ink-secondary)' }}>
                <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-secondary)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>hexagonal port</div>
                <div style={{ fontFamily: 'var(--ink-font-display)', fontSize: 18, fontWeight: 700, color: 'var(--ink-text)', marginBottom: 8 }}>{port[0].toUpperCase() + port.slice(1)}Port</div>
                <div style={{ fontSize: 13, color: 'var(--ink-muted)', lineHeight: 1.6 }}>
                  Resolved at worker startup via <code className="ink-code">getAdapter("{port}")</code>. Plugin never touches the binding directly.
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === 'migrations' && (
          <div style={{ background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 6 }}>
            {p.migrations.map((m, i) => (
              <div key={m} style={{ display: 'grid', gridTemplateColumns: '28px 1fr 80px', gap: 14, padding: '12px 18px', borderTop: i > 0 ? '1px solid var(--ink-border)' : 0, alignItems: 'center' }}>
                <span style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 11, color: 'var(--ink-dim)' }}>{String(i + 1).padStart(2, '0')}</span>
                <code style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 12, color: 'var(--ink-text)' }}>plugins/{slug}/migrations/{m}</code>
                <span style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-accent)', textTransform: 'uppercase', letterSpacing: '0.06em', textAlign: 'right' }}>applied</span>
              </div>
            ))}
          </div>
        )}

        {tab === 'events' && (
          <div style={{ background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 6 }}>
            {p.events.map(([name, desc], i) => (
              <div key={name} style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: 14, padding: '12px 18px', borderTop: i > 0 ? '1px solid var(--ink-border)' : 0, alignItems: 'center' }}>
                <code style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 12, color: p.color }}>{name}</code>
                <span style={{ fontSize: 13, color: 'var(--ink-muted)' }}>{desc}</span>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Manifest source */}
      <section style={{ padding: '28px 0 40px', borderTop: '1px solid var(--ink-border)', marginTop: 28 }}>
        <Eyebrow>plugins/{slug}/manifest.ts</Eyebrow>
        <pre style={{ margin: '14px 0 0', padding: '18px 22px', background: '#0A0A10', border: `1px solid ${p.color}`, borderRadius: 6, fontFamily: 'var(--ink-font-mono)', fontSize: 12, lineHeight: 1.75, color: 'var(--ink-text)', overflow: 'auto' }}>
{`import type { PluginManifest } from '@inkwell/kernel'
import { routes } from './routes'
import { tools } from './mcp'

const manifest: PluginManifest = {
  name: `}<span style={{ color: p.color }}>{`"${p.name}"`}</span>{`,
  version: `}<span style={{ color: 'var(--ink-accent)' }}>"5.2.0"</span>{`,
  description: `}<span style={{ color: 'var(--ink-accent)' }}>{`"${p.desc}"`}</span>{`,
  requiredRole: `}<span style={{ color: ROLE_TONE[p.role] }}>{`"${p.role}"`}</span>{`,
  mountRoutes: (app) => app.route('/api', routes),
  mcpTools: tools,                        // ${p.tools.length} tools
  dashboardWidgets: [${p.widgets.map(w => `"${w[0]}"`).join(', ')}],
  migrations: [${p.migrations.map(m => `"${m}"`).join(', ')}],
}

export default manifest`}
        </pre>
      </section>

      {p.frontmatter && (
        <section style={{ padding: '28px 0 40px', borderTop: '1px solid var(--ink-border)' }}>
          <Eyebrow>Example frontmatter · enforced by Zod</Eyebrow>
          <pre style={{ margin: '14px 0 0', padding: '18px 22px', background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 6, fontFamily: 'var(--ink-font-mono)', fontSize: 12, lineHeight: 1.75, color: 'var(--ink-text)' }}>{p.frontmatter}</pre>
        </section>
      )}
    </div>
  );
}

function Empty({ label }) {
  return (
    <div style={{ padding: '32px 18px', textAlign: 'center', color: 'var(--ink-dim)', fontSize: 13, fontStyle: 'italic' }}>{label}</div>
  );
}

Object.assign(window, { PluginDetail });
