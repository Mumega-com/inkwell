# Inkwell Site — UI Kit

Marketing + docs surface. Recreates the landing, blog listing, post, and docs shells from `Mumega-com/inkwell`.

- **Design source:** `src/components/` (Header, Footer, Reactions, NewsletterCTA, TOC, NetworkHero), `src/styles/base.css`, `inkwell.config.ts`
- **Stack in source:** Astro 6 server components + React islands (`client:visible` / `client:load`)
- **Rebuild in kit:** plain React-in-HTML with Babel, semantically matching the original markup and token usage

Open `index.html` — it's an interactive walk-through of the landing, the post layout with TOC + reactions, the docs shell with sidebar nav, and the Cmd+K palette.
