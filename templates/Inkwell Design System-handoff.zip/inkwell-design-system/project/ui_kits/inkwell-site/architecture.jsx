// Inkwell v8 — Architecture page.
// Microkernel + 19 plugins + 14 hexagonal ports + RBAC + fork instances.
// This is the canonical design-system reference; mirrors Mumega-com/inkwell@main.
const { useState: useStateA, useEffect: useEffectA, useMemo: useMemoA } = React;

// ── Plugin manifests (mirrors /plugins/* from the v8 repo) ────────────────
// kind: core · business · surface · ops · ai
const PLUGINS = [
  // Core
  { name: 'auth',          icon: '⚷', color: 'var(--ink-primary)',   role: 'viewer',  routes: 3, tools: [],                                          widgets: [],                     desc: 'Passwordless OTP (email/phone). Session cookies via KV.',                              kind: 'core' },
  { name: 'content',       icon: '✎', color: 'var(--ink-primary)',   role: 'viewer',  routes: 6, tools: ['publish_content'],                         widgets: [],                     desc: 'MDX + wikilinks. 7 collections. Knowledge graph, versioning, llms.txt, sitemap, RSS.', kind: 'core' },
  { name: 'mcp',           icon: '⎔', color: 'var(--ink-primary)',   role: 'member',  routes: 2, tools: ['site_info'],                               widgets: [],                     desc: 'Streamable HTTP MCP endpoint. Aggregates 16 tools across every active plugin.',        kind: 'core' },
  // Business
  { name: 'dashboard',     icon: '▦', color: 'var(--ink-secondary)', role: 'manager', routes: 9, tools: ['get_dashboard'],                           widgets: ['KPIGrid','Trendline','RecentLeads'], desc: 'Overview, SEO, leads, campaigns, calendar, tasks, squads, wallet, chat, settings.', kind: 'business' },
  { name: 'commerce',      icon: '₪', color: 'var(--ink-secondary)', role: 'manager', routes: 4, tools: ['create_checkout','subscription_status'],  widgets: ['OrdersCard'],         desc: 'Digital products, Stripe checkout, subscriptions, royalty splits.',                   kind: 'business' },
  { name: 'contracts',     icon: '§', color: 'var(--ink-secondary)', role: 'manager', routes: 6, tools: [],                                          widgets: ['ActiveContracts'],    desc: 'E-signature, insurance selection, 9-step shipment tracking, Twilio + Resend.',         kind: 'business' },
  { name: 'courses',       icon: '⎈', color: 'var(--ink-secondary)', role: 'manager', routes: 5, tools: [],                                          widgets: ['Enrollments'],        desc: 'Lessons, drip scheduling, progress tracking, certificates.',                           kind: 'business' },
  { name: 'payments',      icon: '◎', color: 'var(--ink-secondary)', role: 'admin',   routes: 3, tools: [],                                          widgets: ['MRRCard'],            desc: 'Stripe Connect — webhooks, refunds, subscription lifecycle.',                          kind: 'business' },
  { name: 'crm',           icon: '❖', color: 'var(--ink-secondary)', role: 'manager', routes: 4, tools: [],                                          widgets: ['CRMPipeline'],        desc: 'Contacts, opportunities, custom fields. Tenant-scoped via CRMPort.',                   kind: 'business' },
  { name: 'agency',        icon: '⚐', color: 'var(--ink-secondary)', role: 'admin',   routes: 4, tools: [],                                          widgets: [],                     desc: 'Multi-client management — projects, retainers, handoffs.',                             kind: 'business' },
  // Surface
  { name: 'chat',          icon: '◌', color: 'var(--ink-accent)',    role: 'viewer',  routes: 2, tools: [],                                          widgets: [],                     desc: 'Live chat widget. Forwards to MCP bus. FAQ fallback.',                                 kind: 'surface' },
  { name: 'telegram',      icon: '✈', color: 'var(--ink-accent)',    role: 'admin',   routes: 2, tools: ['send_telegram'],                           widgets: [],                     desc: 'Webhook receiver, message routing, /status + /report commands.',                       kind: 'surface' },
  { name: 'notifications', icon: '♪', color: 'var(--ink-accent)',    role: 'member',  routes: 3, tools: [],                                          widgets: ['Bell'],               desc: 'In-app bell + Resend email + Twilio SMS. Typed templates, delivery log.',              kind: 'surface' },
  { name: 'seo',           icon: '⌖', color: 'var(--ink-accent)',    role: 'manager', routes: 3, tools: ['get_seo_data'],                            widgets: ['SEOScorecard'],       desc: 'GSC + GA4 flywheel — daily ingest, WoW scoring, programmatic geo pages.',              kind: 'surface' },
  { name: 'analytics',     icon: '◐', color: 'var(--ink-accent)',    role: 'manager', routes: 2, tools: [],                                          widgets: ['AnalyticsStrip'],     desc: 'GSC + GA4 daily ingest, week-over-week scoring, writes the flywheel signal.',          kind: 'surface' },
  { name: 'feedback',      icon: '☲', color: 'var(--ink-accent)',    role: 'member',  routes: 4, tools: [],                                          widgets: ['NPSCard'],            desc: 'Surveys, NPS, feature voting. Optional LLM auto-classification.',                      kind: 'surface' },
  // Ops
  { name: 'onboarding',    icon: '↴', color: '#8B5CF6',              role: 'owner',   routes: 4, tools: [],                                          widgets: [],                     desc: 'Fork setup wizard. Business profile, team selection, MCP connection.',                 kind: 'ops' },
  { name: 'diagnostics',   icon: '◉', color: '#8B5CF6',              role: 'admin',   routes: 3, tools: [],                                          widgets: ['HealthStrip'],        desc: 'Health checks, adapter status, FMAAP safety gate, A/B testing.',                       kind: 'ops' },
  { name: 'discovery',     icon: '✶', color: '#8B5CF6',              role: 'manager', routes: 3, tools: ['get_leads'],                                widgets: ['LeadsFunnel'],        desc: '25-question business scan, 5-dimension score, 90-day plan, grant scanner.',            kind: 'ops' },
  { name: 'questionnaire', icon: '?', color: '#8B5CF6',              role: 'member',  routes: 3, tools: [],                                          widgets: [],                     desc: 'Survey builder with scoring and branching.',                                           kind: 'ops' },
  { name: 'automation',    icon: '↻', color: '#8B5CF6',              role: 'admin',   routes: 4, tools: ['create_task'],                              widgets: ['TaskBoard'],          desc: 'Task runner, scheduled jobs, event-driven workflows.',                                 kind: 'ops' },
  // AI
  { name: 'organism',      icon: '✦', color: '#A78BFA',              role: 'owner',   routes: 4, tools: ['remember','recall','browse_marketplace'], widgets: ['AgentBudget'],        desc: 'Managed AI agent — provision, budget, usage tracking.',                                kind: 'ai' },
  { name: 'sync',          icon: '⇅', color: '#A78BFA',              role: 'admin',   routes: 2, tools: [],                                          widgets: [],                     desc: 'Pull content from Obsidian, GitHub, Notion, Google Drive via ContentSourcePort.',      kind: 'ai' },
  { name: 'media',         icon: '◨', color: '#A78BFA',              role: 'member',  routes: 5, tools: ['upload_media','describe_image','generate_image','search_media'], widgets: ['MediaGrid'], desc: 'R2 + Workers AI — upload, vision, Whisper transcription, Flux image gen.',            kind: 'ai' },
];

// 14 hexagonal ports (mirrors kernel/ports/generated/ from SOS handoff v0.9.0)
const PORTS = [
  { key: 'database',      label: 'DatabasePort',      desc: 'query · execute · batch',                             impl: 'D1 · Postgres · MySQL' },
  { key: 'auth',          label: 'AuthPort',          desc: 'getUser · requireUser',                               impl: 'CF Access · Auth.js · custom' },
  { key: 'session',       label: 'SessionPort',       desc: 'get · set · delete',                                  impl: 'KV · Redis' },
  { key: 'content',       label: 'ContentPort',       desc: 'getPage · putPage · invalidate',                      impl: 'KV · S3 · filesystem' },
  { key: 'contentSource', label: 'ContentSourcePort', desc: 'list · syncSince',                                    impl: 'Obsidian · GitHub · Notion · GDrive' },
  { key: 'media',         label: 'MediaPort',         desc: 'upload · describe · transcribe · generateImage',      impl: 'R2 + Workers AI' },
  { key: 'storage',       label: 'StoragePort',       desc: 'put · get · delete',                                  impl: 'R2 · S3 · GCS' },
  { key: 'graph',         label: 'GraphPort',         desc: 'nodes · edges · backlinks',                           impl: 'D1' },
  { key: 'agent',         label: 'AgentPort',         desc: 'provision · budget · usage',                          impl: 'D1' },
  { key: 'crm',           label: 'CRMPort',           desc: 'contacts · opportunities · customFields',             impl: 'GHL · in-house' },
  { key: 'search',        label: 'SearchPort',        desc: 'index · search · delete',                             impl: 'D1 FTS · Vectorize' },
  { key: 'bus',           label: 'BusPort',           desc: 'send · broadcast · subscribe',                        impl: 'standalone · SOS network' },
  { key: 'memory',        label: 'MemoryPort',        desc: 'remember · recall',                                   impl: 'standalone · mirror' },
  { key: 'economy',       label: 'EconomyPort',       desc: 'charge · transfer · balance',                         impl: 'standalone · SOS' },
];

const ROLES = ['viewer', 'member', 'manager', 'admin', 'owner'];
const ROLE_COLOR = {
  viewer: 'var(--ink-dim)',
  member: 'var(--ink-muted)',
  manager: 'var(--ink-secondary)',
  admin: 'var(--ink-primary)',
  owner: 'var(--ink-accent)',
};

// 16 MCP tools, grouped by owning plugin — surfaced in the MCP card.
const MCP_TOOLS = [
  ['publish_content', 'content', 'Write markdown directly to the site.'],
  ['get_dashboard', 'dashboard', 'All KPIs in one call.'],
  ['get_seo_data', 'seo', 'GSC + GA4 snapshot.'],
  ['get_leads', 'discovery', 'Lead list from D1.'],
  ['create_checkout', 'commerce', 'Start a Stripe session.'],
  ['subscription_status', 'commerce', 'Check subscription by email.'],
  ['send_telegram', 'telegram', 'Message your Telegram bot.'],
  ['site_info', 'mcp', 'Site config + feature flags.'],
  ['remember', 'organism', 'Store to agent memory.'],
  ['recall', 'organism', 'Retrieve from agent memory.'],
  ['create_task', 'automation', 'Create a task for your team.'],
  ['browse_marketplace', 'organism', 'Discover plugins and services.'],
  ['upload_media', 'media', 'Upload image/video, auto-analyze with AI.'],
  ['describe_image', 'media', 'Run vision analysis on an asset.'],
  ['generate_image', 'media', 'Generate image from text prompt.'],
  ['search_media', 'media', 'Search media by text query.'],
];

// ── Fork instances — v8 uses `instances/` overrides, not branch forks ────
const PERSONAS = {
  inkwell: {
    name: 'Inkwell',
    tagline: 'Fork the organism. Ship the site.',
    primary: '#D4A017',
    plugins: ['auth','content','mcp','dashboard','chat','notifications','seo','diagnostics','media','organism'],
    copy: 'The default instance. Content-first, agent-operated, free on Cloudflare.',
    adapters: { bus: 'standalone', memory: 'standalone', economy: 'standalone', media: 'cf' },
  },
  torivers: {
    name: 'Torivers',
    tagline: 'Classic car shipping, continent-wide.',
    primary: '#EA580C',
    plugins: ['auth','content','mcp','dashboard','contracts','payments','crm','telegram','notifications','chat','diagnostics','discovery','seo','feedback','automation','media'],
    copy: 'Nearly every plugin on. Contracts + Telegram steering are the daily drivers.',
    adapters: { bus: 'sos', memory: 'mirror', economy: 'sos', media: 'cf' },
  },
  atelier: {
    name: 'Atelier & Co',
    tagline: 'A studio practice, published.',
    primary: '#10B981',
    plugins: ['auth','content','mcp','dashboard','commerce','courses','payments','chat','seo','media'],
    copy: 'Commerce + courses. No Telegram, no SMS — email-only via Resend.',
    adapters: { bus: 'standalone', memory: 'standalone', economy: 'standalone', media: 'cf' },
  },
  vault: {
    name: 'Vault Advisors',
    tagline: 'Quiet. Precise. Referral-only.',
    primary: '#06B6D4',
    plugins: ['auth','content','mcp','diagnostics','onboarding','crm'],
    copy: 'Headless. Content + kernel + a private CRM. Internal portal only.',
    adapters: { bus: 'standalone', memory: 'standalone', economy: 'standalone', media: 'cf' },
  },
};

function Architecture({ onNavigate }) {
  const [selected, setSelected] = useStateA('content');
  const [persona, setPersona] = useStateA('inkwell');
  const [filter, setFilter] = useStateA('all');

  const active = PLUGINS.find(p => p.name === selected);
  const enabledSet = useMemoA(() => new Set(PERSONAS[persona].plugins), [persona]);

  const kinds = [
    ['all', 'All'], ['core', 'Core'], ['business', 'Business'], ['surface', 'Surface'], ['ops', 'Ops'], ['ai', 'AI'],
  ];
  const visible = filter === 'all' ? PLUGINS : PLUGINS.filter(p => p.kind === filter);

  return (
    <div>
      {/* ── Header ─────────────────────────────────────────────────────── */}
      <section style={{ padding: '64px 0 28px' }}>
        <Eyebrow>Design system · v8 microkernel · SOS-generated ports</Eyebrow>
        <h1 style={{ fontFamily: 'var(--ink-font-display)', fontSize: '3.25rem', fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1.02, margin: '14px 0 18px', maxWidth: 880 }}>
          A small kernel, a crowd of plugins, fourteen ports to the outside world.
        </h1>
        <p style={{ fontSize: 18, lineHeight: 1.55, color: 'var(--ink-muted)', margin: '0 0 8px', maxWidth: 700 }}>
          Inkwell v8 is a microkernel. The kernel knows nothing about your business — it loads plugins, mounts their routes, collects their MCP tools, and hands them typed ports for the world outside. Port types are generated from Pydantic schemas in SOS so Python and TypeScript share one contract.
        </p>
        <p style={{ fontSize: 14, lineHeight: 1.6, color: 'var(--ink-dim)', margin: 0, maxWidth: 700, fontFamily: 'var(--ink-font-mono)' }}>
          kernel · 5 files · ~430 lines &nbsp;·&nbsp; plugins · {PLUGINS.length} modules &nbsp;·&nbsp; ports · {PORTS.length} interfaces &nbsp;·&nbsp; mcp tools · {MCP_TOOLS.length} &nbsp;·&nbsp; generated from <span style={{ color: 'var(--ink-accent)' }}>sos/contracts/ports</span>
        </p>
      </section>

      {/* ── Diagram ─────────────────────────────────────────────────────── */}
      <section style={{ padding: '8px 0 28px' }}>
        <div style={{ background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 8, padding: 28 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '240px 1fr 260px', gap: 28, alignItems: 'stretch' }}>
            {/* Plugins column */}
            <div>
              <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--ink-dim)', marginBottom: 10 }}>Plugins ({PLUGINS.length})</div>
              <div style={{ display: 'grid', gap: 4, maxHeight: 520, overflow: 'auto' }}>
                {PLUGINS.map(p => (
                  <div key={p.name} onClick={() => setSelected(p.name)} style={{
                    display: 'grid', gridTemplateColumns: '22px 1fr auto', gap: 8, padding: '6px 10px',
                    border: `1px solid ${selected === p.name ? p.color : 'var(--ink-border)'}`,
                    background: selected === p.name ? `${p.color}14` : 'var(--ink-bg)',
                    borderRadius: 4, cursor: 'pointer', fontFamily: 'var(--ink-font-mono)', fontSize: 11,
                    color: selected === p.name ? p.color : 'var(--ink-text)',
                    alignItems: 'center', transition: 'all 150ms',
                  }}>
                    <span style={{ color: p.color, fontSize: 14, textAlign: 'center' }}>{p.icon}</span>
                    <span>{p.name}</span>
                    <span style={{ color: 'var(--ink-dim)', fontSize: 9, textTransform: 'uppercase' }}>{p.kind}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Kernel center */}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
              <div style={{
                width: '100%', aspectRatio: '1 / 1', maxWidth: 360,
                border: '2px solid var(--ink-primary)',
                background: 'radial-gradient(circle at center, rgba(212,160,23,0.10), transparent 70%)',
                borderRadius: 12, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                position: 'relative',
              }}>
                <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'var(--ink-primary)', marginBottom: 6 }}>kernel · v8</div>
                <div style={{ fontFamily: 'var(--ink-font-display)', fontSize: 28, fontWeight: 700, color: 'var(--ink-text)', marginBottom: 14 }}>Inkwell</div>
                <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 11, color: 'var(--ink-muted)', textAlign: 'center', lineHeight: 1.8 }}>
                  plugin-loader<br/>adapter-registry<br/>roles · theme · types<br/>
                  <span style={{ color: 'var(--ink-dim)' }}>ports/generated ← SOS</span>
                </div>
              </div>
              <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--ink-dim)', marginTop: 14 }}>← manifests in · routes + tools out →</div>
            </div>

            {/* Ports column */}
            <div>
              <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--ink-dim)', marginBottom: 10 }}>Ports ({PORTS.length})</div>
              <div style={{ display: 'grid', gap: 6, maxHeight: 520, overflow: 'auto' }}>
                {PORTS.map(port => (
                  <div key={port.key} style={{
                    padding: '8px 10px', border: '1px solid var(--ink-border)', background: 'var(--ink-bg)',
                    borderRadius: 4,
                  }}>
                    <div style={{ fontFamily: 'var(--ink-font-display)', fontSize: 11.5, fontWeight: 600, color: 'var(--ink-secondary)', marginBottom: 2 }}>{port.label}</div>
                    <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 9.5, color: 'var(--ink-dim)' }}>{port.desc}</div>
                    <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 9.5, color: 'var(--ink-muted)', marginTop: 3 }}>↳ {port.impl}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Plugin grid + manifest inspector ─────────────────────────────── */}
      <section style={{ padding: '28px 0', borderTop: '1px solid var(--ink-border)' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 16 }}>
          <div>
            <Eyebrow>Plugin registry</Eyebrow>
            <h2 style={{ fontFamily: 'var(--ink-font-display)', fontSize: '1.75rem', fontWeight: 700, letterSpacing: '-0.02em', margin: '8px 0 0' }}>Every feature is a plugin.</h2>
          </div>
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
            {kinds.map(([k, l]) => (
              <button key={k} onClick={() => setFilter(k)} style={{
                padding: '6px 12px', background: filter === k ? 'var(--ink-primary)' : 'transparent',
                color: filter === k ? '#0A0A10' : 'var(--ink-muted)',
                border: `1px solid ${filter === k ? 'var(--ink-primary)' : 'var(--ink-border)'}`,
                borderRadius: 4, fontFamily: 'var(--ink-font-mono)', fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.06em', cursor: 'pointer',
              }}>{l}</button>
            ))}
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: 18, alignItems: 'start' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
            {visible.map(p => (
              <div key={p.name} onClick={() => setSelected(p.name)} style={{
                padding: '14px 14px 12px', border: `1px solid ${selected === p.name ? p.color : 'var(--ink-border)'}`,
                background: selected === p.name ? `${p.color}10` : 'var(--ink-surface)',
                borderRadius: 6, cursor: 'pointer', transition: 'all 150ms',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                  <span style={{ color: p.color, fontSize: 16 }}>{p.icon}</span>
                  <span style={{ fontFamily: 'var(--ink-font-display)', fontSize: 13, fontWeight: 600 }}>{p.name}</span>
                  <span style={{ marginLeft: 'auto', fontFamily: 'var(--ink-font-mono)', fontSize: 9, textTransform: 'uppercase', color: ROLE_COLOR[p.role], letterSpacing: '0.06em' }}>{p.role}</span>
                </div>
                <div style={{ fontSize: 12, color: 'var(--ink-muted)', lineHeight: 1.5, marginBottom: 8, minHeight: 54 }}>{p.desc}</div>
                <div style={{ display: 'flex', gap: 6, fontFamily: 'var(--ink-font-mono)', fontSize: 9, color: 'var(--ink-dim)' }}>
                  <span>{p.routes} routes</span>
                  <span>·</span>
                  <span>{p.tools.length} tools</span>
                  <span>·</span>
                  <span>{p.widgets.length} widgets</span>
                </div>
              </div>
            ))}
          </div>

          {/* Manifest inspector */}
          {active && (
            <div style={{ position: 'sticky', top: 20, background: '#0A0A10', border: `1px solid ${active.color}`, borderRadius: 6, padding: '18px 20px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                <span style={{ color: active.color, fontSize: 20 }}>{active.icon}</span>
                <div>
                  <div style={{ fontFamily: 'var(--ink-font-display)', fontSize: 15, fontWeight: 700 }}>{active.name}</div>
                  <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-dim)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>plugins/{active.name}/manifest.ts</div>
                </div>
                <button onClick={() => onNavigate('plugin')} style={{ marginLeft: 'auto', padding: '4px 10px', fontFamily: 'var(--ink-font-mono)', fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.06em', background: 'transparent', color: active.color, border: `1px solid ${active.color}`, borderRadius: 3, cursor: 'pointer' }}>open →</button>
              </div>
              <pre style={{ margin: 0, fontFamily: 'var(--ink-font-mono)', fontSize: 11.5, lineHeight: 1.75, color: 'var(--ink-text)', overflow: 'auto' }}>
<span style={{ color: 'var(--ink-dim)' }}>{`// PluginManifest`}</span>{'\n'}
<span style={{ color: 'var(--ink-secondary)' }}>name</span>: <span style={{ color: active.color }}>{`"${active.name}"`}</span>,{'\n'}
<span style={{ color: 'var(--ink-secondary)' }}>version</span>: <span style={{ color: 'var(--ink-accent)' }}>"8.0.0"</span>,{'\n'}
<span style={{ color: 'var(--ink-secondary)' }}>requiredRole</span>: <span style={{ color: ROLE_COLOR[active.role] }}>{`"${active.role}"`}</span>,{'\n'}
<span style={{ color: 'var(--ink-secondary)' }}>mountRoutes</span>: <span style={{ color: 'var(--ink-muted)' }}>{`(app) => { /* +${active.routes} */ }`}</span>,{'\n'}
<span style={{ color: 'var(--ink-secondary)' }}>mcpTools</span>: [{active.tools.length === 0 ? <span style={{ color: 'var(--ink-dim)' }}>{' /* none */ '}</span> : (
  <>{'\n'}{active.tools.map(t => <span key={t}>  <span style={{ color: active.color }}>{`"${t}"`}</span>,{'\n'}</span>)}</>
)}],{'\n'}
<span style={{ color: 'var(--ink-secondary)' }}>dashboardWidgets</span>: [{active.widgets.length === 0 ? <span style={{ color: 'var(--ink-dim)' }}>{' '}</span> : (
  <>{active.widgets.map((w, i) => <span key={w}><span style={{ color: active.color }}>{`"${w}"`}</span>{i < active.widgets.length - 1 ? ', ' : ''}</span>)}</>
)}],{'\n'}
<span style={{ color: 'var(--ink-secondary)' }}>migrations</span>: [<span style={{ color: 'var(--ink-accent)' }}>"001_init.sql"</span>],
              </pre>
            </div>
          )}
        </div>
      </section>

      {/* ── MCP tools surface ────────────────────────────────────────────── */}
      <section style={{ padding: '28px 0', borderTop: '1px solid var(--ink-border)' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 16, gap: 16, flexWrap: 'wrap' }}>
          <div>
            <Eyebrow>MCP server · 16 tools</Eyebrow>
            <h2 style={{ fontFamily: 'var(--ink-font-display)', fontSize: '1.5rem', fontWeight: 700, letterSpacing: '-0.02em', margin: '8px 0 0' }}>One URL. Every AI client.</h2>
          </div>
          <pre style={{ margin: 0, padding: '10px 14px', background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 4, fontFamily: 'var(--ink-font-mono)', fontSize: 11, color: 'var(--ink-text)' }}>
<span style={{ color: 'var(--ink-dim)' }}>POST</span> <span style={{ color: 'var(--ink-primary)' }}>/mcp</span>  <span style={{ color: 'var(--ink-dim)' }}>Streamable HTTP · Bearer token</span>
          </pre>
        </div>

        <div style={{ background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 6 }}>
          {MCP_TOOLS.map(([name, owner, desc], i) => {
            const p = PLUGINS.find(x => x.name === owner);
            return (
              <div key={name} style={{ display: 'grid', gridTemplateColumns: '220px 120px 1fr', gap: 14, padding: '10px 18px', borderTop: i > 0 ? '1px solid var(--ink-border)' : 0, alignItems: 'center' }}>
                <code style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 12, color: p ? p.color : 'var(--ink-text)', fontWeight: 600 }}>{name}</code>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ color: p ? p.color : 'var(--ink-dim)', fontSize: 12 }}>{p?.icon}</span>
                  <span style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{owner}</span>
                </div>
                <span style={{ fontSize: 13, color: 'var(--ink-muted)' }}>{desc}</span>
              </div>
            );
          })}
        </div>
      </section>

      {/* ── RBAC matrix ──────────────────────────────────────────────────── */}
      <section style={{ padding: '28px 0', borderTop: '1px solid var(--ink-border)' }}>
        <Eyebrow>RBAC · role hierarchy</Eyebrow>
        <h2 style={{ fontFamily: 'var(--ink-font-display)', fontSize: '1.5rem', fontWeight: 700, letterSpacing: '-0.02em', margin: '8px 0 16px' }}>Five roles. Every plugin declares a minimum.</h2>

        <div style={{ background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 6, padding: '18px 20px', overflow: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: 'var(--ink-font-mono)', fontSize: 11 }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--ink-border)' }}>
                <th style={{ textAlign: 'left', padding: '8px 10px', color: 'var(--ink-dim)', textTransform: 'uppercase', letterSpacing: '0.06em', fontSize: 9 }}>Plugin</th>
                <th style={{ textAlign: 'left', padding: '8px 10px', color: 'var(--ink-dim)', textTransform: 'uppercase', letterSpacing: '0.06em', fontSize: 9 }}>kind</th>
                {ROLES.map(r => (
                  <th key={r} style={{ padding: '8px 10px', color: ROLE_COLOR[r], textTransform: 'uppercase', letterSpacing: '0.06em', fontSize: 9 }}>{r}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {PLUGINS.map(p => {
                const reqIdx = ROLES.indexOf(p.role);
                return (
                  <tr key={p.name} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                    <td style={{ padding: '7px 10px', color: 'var(--ink-text)' }}>
                      <span style={{ color: p.color, marginRight: 8 }}>{p.icon}</span>{p.name}
                    </td>
                    <td style={{ padding: '7px 10px', color: 'var(--ink-dim)', fontSize: 10, textTransform: 'uppercase' }}>{p.kind}</td>
                    {ROLES.map((r, i) => (
                      <td key={r} style={{ padding: '7px 10px', textAlign: 'center' }}>
                        <span style={{
                          display: 'inline-block', width: 10, height: 10, borderRadius: '50%',
                          background: i >= reqIdx ? p.color : 'transparent',
                          border: `1px solid ${i >= reqIdx ? p.color : 'var(--ink-border)'}`,
                        }} />
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* ── Fork instances ───────────────────────────────────────────────── */}
      <section style={{ padding: '28px 0', borderTop: '1px solid var(--ink-border)' }}>
        <Eyebrow>Instance = customer</Eyebrow>
        <h2 style={{ fontFamily: 'var(--ink-font-display)', fontSize: '1.75rem', fontWeight: 700, letterSpacing: '-0.02em', margin: '8px 0 8px' }}>Same kernel. Different <code className="ink-code">config.plugins[]</code>.</h2>
        <p style={{ fontSize: 14, color: 'var(--ink-muted)', marginBottom: 20, maxWidth: 700, lineHeight: 1.6 }}>
          An <code className="ink-code">instance</code> is a customer deployment. The kernel never changes — <code className="ink-code">inkwell.config.ts</code> in <code className="ink-code">instances/&lt;name&gt;/</code> picks plugins, sets the brand, and chooses adapters. Swap the instance below to see the same architecture load differently. Bootstrap with <code className="ink-code">npx create-inkwell my-site</code>.
        </p>

        <div style={{ display: 'flex', gap: 6, marginBottom: 18, flexWrap: 'wrap' }}>
          {Object.entries(PERSONAS).map(([k, v]) => (
            <button key={k} onClick={() => setPersona(k)} style={{
              padding: '8px 14px', background: persona === k ? v.primary : 'transparent',
              color: persona === k ? '#0A0A10' : 'var(--ink-muted)',
              border: `1px solid ${persona === k ? v.primary : 'var(--ink-border)'}`,
              borderRadius: 4, fontFamily: 'var(--ink-font-display)', fontSize: 12, fontWeight: 600, cursor: 'pointer',
            }}>{v.name}</button>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '420px 1fr', gap: 18 }}>
          {/* Config preview */}
          <div style={{ background: '#0A0A10', border: `1px solid ${PERSONAS[persona].primary}`, borderRadius: 6, padding: '18px 20px' }}>
            <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--ink-dim)', marginBottom: 10 }}>instances/{persona}/inkwell.config.ts</div>
            <pre style={{ margin: 0, fontFamily: 'var(--ink-font-mono)', fontSize: 11.5, lineHeight: 1.7, color: 'var(--ink-text)', maxHeight: 420, overflow: 'auto' }}>
{`name: `}<span style={{ color: PERSONAS[persona].primary }}>{`"${PERSONAS[persona].name}"`}</span>{`,
tagline: `}<span style={{ color: 'var(--ink-accent)' }}>{`"${PERSONAS[persona].tagline}"`}</span>{`,
theme: {
  colors: {
    primary: `}<span style={{ color: PERSONAS[persona].primary }}>{`"${PERSONAS[persona].primary}"`}</span>{`,
  },
},
plugins: [
`}{PERSONAS[persona].plugins.map(p => <span key={p}>  <span style={{ color: 'var(--ink-accent)' }}>{`"${p}"`}</span>,{'\n'}</span>)}{`],
adapters: {
`}{Object.entries(PERSONAS[persona].adapters).map(([k,v]) => <span key={k}>  <span style={{ color: 'var(--ink-secondary)' }}>{k}</span>: <span style={{ color: 'var(--ink-accent)' }}>{`"${v}"`}</span>,{'\n'}</span>)}{`},`}
            </pre>
            <div style={{ marginTop: 14, paddingTop: 12, borderTop: '1px solid rgba(255,255,255,0.06)', fontSize: 12, color: 'var(--ink-muted)', lineHeight: 1.6 }}>
              {PERSONAS[persona].copy}
            </div>
          </div>

          {/* Live plugin board */}
          <div style={{ background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 6, padding: '18px 20px' }}>
            <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--ink-dim)', marginBottom: 12, display: 'flex', justifyContent: 'space-between' }}>
              <span>loaded plugins</span>
              <span>{PERSONAS[persona].plugins.length} / {PLUGINS.length} active</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6 }}>
              {PLUGINS.map(p => {
                const on = enabledSet.has(p.name);
                return (
                  <div key={p.name} style={{
                    padding: '8px 10px', border: `1px solid ${on ? p.color : 'var(--ink-border)'}`,
                    background: on ? `${p.color}12` : 'transparent',
                    opacity: on ? 1 : 0.3, borderRadius: 4,
                    display: 'flex', alignItems: 'center', gap: 8, transition: 'all 300ms',
                  }}>
                    <span style={{ color: p.color, fontSize: 13 }}>{p.icon}</span>
                    <span style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10.5, color: on ? 'var(--ink-text)' : 'var(--ink-dim)' }}>{p.name}</span>
                    <span style={{ marginLeft: 'auto', fontFamily: 'var(--ink-font-mono)', fontSize: 9, color: on ? 'var(--ink-accent)' : 'var(--ink-dim)' }}>{on ? 'on' : 'off'}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* ── Adapter matrix (provider-agnostic) ───────────────────────────── */}
      <section style={{ padding: '28px 0', borderTop: '1px solid var(--ink-border)' }}>
        <Eyebrow>Provider-agnostic · v8</Eyebrow>
        <h2 style={{ fontFamily: 'var(--ink-font-display)', fontSize: '1.5rem', fontWeight: 700, letterSpacing: '-0.02em', margin: '8px 0 8px' }}>Swap infrastructure. Change zero plugin code.</h2>
        <p style={{ fontSize: 14, color: 'var(--ink-muted)', margin: '0 0 18px', maxWidth: 680, lineHeight: 1.6 }}>
          Each port has a default Cloudflare adapter and one or more alternatives. Point an env var at a Postgres or Redis client and the same plugins run on any stack.
        </p>
        <div style={{ background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 6, overflow: 'hidden' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '180px 1fr 1fr 1.2fr', padding: '10px 16px', borderBottom: '1px solid var(--ink-border)', fontFamily: 'var(--ink-font-mono)', fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--ink-dim)' }}>
            <span>port</span><span>cloudflare default</span><span>alternative</span><span>env binding</span>
          </div>
          {[
            ['DatabasePort',  'D1',  'Postgres · MySQL',  'DB_CORE_CLIENT'],
            ['StoragePort',   'R2',  'S3 · GCS',          'S3_CLIENT'],
            ['SessionPort',   'KV',  'Redis',             'REDIS_CLIENT'],
            ['ContentPort',   'KV',  'Filesystem',        'FS_CLIENT + CONTENT_DIR'],
            ['MediaPort',     'R2 + Workers AI', 'S3 + OpenAI', 'MEDIA_PROVIDER'],
            ['BusPort',       'standalone',      'SOS network', 'ADAPTER_BUS'],
            ['MemoryPort',    'standalone',      'SOS mirror',  'ADAPTER_MEMORY'],
            ['EconomyPort',   'standalone',      'SOS',         'ADAPTER_ECONOMY'],
          ].map(([port, def, alt, env], i) => (
            <div key={port} style={{ display: 'grid', gridTemplateColumns: '180px 1fr 1fr 1.2fr', padding: '10px 16px', borderTop: i > 0 ? '1px solid rgba(255,255,255,0.04)' : 0, fontFamily: 'var(--ink-font-mono)', fontSize: 11.5, alignItems: 'center' }}>
              <span style={{ color: 'var(--ink-secondary)' }}>{port}</span>
              <span style={{ color: 'var(--ink-text)' }}>{def}</span>
              <span style={{ color: 'var(--ink-muted)' }}>{alt}</span>
              <span style={{ color: 'var(--ink-accent)', fontSize: 10.5 }}>{env}</span>
            </div>
          ))}
        </div>
      </section>

      {/* ── Generated ports callout (SOS handoff) ────────────────────────── */}
      <section style={{ padding: '28px 0', borderTop: '1px solid var(--ink-border)' }}>
        <Eyebrow>kernel/ports/generated · single source of truth</Eyebrow>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, marginTop: 12 }}>
          <div style={{ background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 6, padding: '18px 20px' }}>
            <h3 style={{ fontFamily: 'var(--ink-font-display)', fontSize: 15, fontWeight: 700, margin: '0 0 10px' }}>Python defines. TypeScript follows.</h3>
            <p style={{ fontSize: 13, color: 'var(--ink-muted)', lineHeight: 1.6, margin: 0 }}>
              SOS owns 13 <code className="ink-code">Protocol</code> ports and 75+ Pydantic models. <code className="ink-code">make contracts</code> exports JSON Schemas, runs <code className="ink-code">json-schema-to-typescript</code>, and writes TS modules into <code className="ink-code">kernel/ports/generated/</code>. A drift guard fails CI when the repos disagree.
            </p>
            <div style={{ marginTop: 12, paddingTop: 12, borderTop: '1px solid var(--ink-border)', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, fontFamily: 'var(--ink-font-mono)', fontSize: 11 }}>
              <div><span style={{ color: 'var(--ink-dim)' }}>ports</span> <span style={{ color: 'var(--ink-primary)' }}>14</span></div>
              <div><span style={{ color: 'var(--ink-dim)' }}>models</span> <span style={{ color: 'var(--ink-primary)' }}>87</span></div>
              <div><span style={{ color: 'var(--ink-dim)' }}>languages</span> <span style={{ color: 'var(--ink-primary)' }}>2</span></div>
              <div><span style={{ color: 'var(--ink-dim)' }}>hand-edits</span> <span style={{ color: 'var(--ink-danger)' }}>0</span></div>
            </div>
          </div>
          <pre style={{ margin: 0, padding: '18px 20px', background: '#0A0A10', border: '1px solid var(--ink-primary)', borderRadius: 6, fontFamily: 'var(--ink-font-mono)', fontSize: 11.5, lineHeight: 1.75, color: 'var(--ink-text)', overflow: 'auto' }}>
<span style={{ color: 'var(--ink-dim)' }}>{`# regenerate both sides`}</span>{'\n'}
<span style={{ color: 'var(--ink-primary)' }}>$</span> cd SOS && make contracts{'\n'}
<span style={{ color: 'var(--ink-dim)' }}>{`# CI drift guard`}</span>{'\n'}
<span style={{ color: 'var(--ink-primary)' }}>$</span> make contracts-check{'\n\n'}
<span style={{ color: 'var(--ink-dim)' }}>{`# in inkwell`}</span>{'\n'}
<span style={{ color: 'var(--ink-primary)' }}>$</span> npm run gen:types{'\n'}
<span style={{ color: 'var(--ink-primary)' }}>$</span> cd kernel && npx vitest run{'\n\n'}
<span style={{ color: 'var(--ink-dim)' }}>{`// kernel/types.ts`}</span>{'\n'}
<span style={{ color: 'var(--ink-secondary)' }}>export</span> * <span style={{ color: 'var(--ink-secondary)' }}>from</span> <span style={{ color: 'var(--ink-accent)' }}>"./ports/generated"</span>;
          </pre>
        </div>
      </section>

      {/* ── Theme tokens ─────────────────────────────────────────────────── */}
      <section style={{ padding: '28px 0', borderTop: '1px solid var(--ink-border)' }}>
        <Eyebrow>Theme · kernel/theme.ts</Eyebrow>
        <h2 style={{ fontFamily: 'var(--ink-font-display)', fontSize: '1.5rem', fontWeight: 700, letterSpacing: '-0.02em', margin: '8px 0 16px' }}>CSS variables generated from config.</h2>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
          <div style={{ background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 6, padding: '18px 20px' }}>
            <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-dim)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 10 }}>Core palette</div>
            {[
              ['--ink-primary', '#D4A017', 'action, brand'],
              ['--ink-secondary', '#06B6D4', 'data, ports'],
              ['--ink-accent', '#10B981', 'success, active'],
              ['--ink-danger', '#EF4444', 'errors, refusals'],
              ['--ink-bg', '#0A0A10', 'page surface'],
              ['--ink-surface', '#151519', 'cards'],
              ['--ink-text', '#EDEDF0', 'body'],
              ['--ink-muted', 'rgba(255,255,255,0.55)', 'secondary text'],
              ['--ink-border', 'rgba(255,255,255,0.10)', 'dividers'],
            ].map(([tok, val, use]) => (
              <div key={tok} style={{ display: 'grid', gridTemplateColumns: '22px 1fr 1fr', gap: 10, padding: '5px 0', alignItems: 'center' }}>
                <span style={{ width: 18, height: 18, borderRadius: 3, background: val, border: '1px solid rgba(255,255,255,0.1)' }} />
                <span style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 11, color: 'var(--ink-text)' }}>{tok}</span>
                <span style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-dim)' }}>{use}</span>
              </div>
            ))}
          </div>

          <div style={{ background: 'var(--ink-surface)', border: '1px solid var(--ink-border)', borderRadius: 6, padding: '18px 20px' }}>
            <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-dim)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 10 }}>Type</div>
            <div style={{ padding: '12px 0', borderBottom: '1px solid var(--ink-border)' }}>
              <div style={{ fontFamily: 'var(--ink-font-display)', fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em' }}>Display · JetBrains Mono</div>
              <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-dim)', marginTop: 4 }}>--ink-font-display · headings, brand</div>
            </div>
            <div style={{ padding: '12px 0', borderBottom: '1px solid var(--ink-border)' }}>
              <div style={{ fontFamily: 'var(--ink-font-body)', fontSize: 16, lineHeight: 1.5 }}>Body · system-ui, -apple-system, sans-serif. Quiet and legible.</div>
              <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-dim)', marginTop: 4 }}>--ink-font-body · prose</div>
            </div>
            <div style={{ padding: '12px 0' }}>
              <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 13 }}>mono · mcpTools · {`[0x0A0A10]`}</div>
              <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-dim)', marginTop: 4 }}>--ink-font-mono · code, labels, signals</div>
            </div>

            <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 10, color: 'var(--ink-dim)', textTransform: 'uppercase', letterSpacing: '0.08em', marginTop: 18, marginBottom: 8 }}>Geometry</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, fontFamily: 'var(--ink-font-mono)', fontSize: 11 }}>
              <div><div style={{ color: 'var(--ink-muted)' }}>radius</div><div>6px</div></div>
              <div><div style={{ color: 'var(--ink-muted)' }}>content</div><div>680px</div></div>
              <div><div style={{ color: 'var(--ink-muted)' }}>page</div><div>1200px</div></div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Kernel primitives cheat sheet ────────────────────────────────── */}
      <section style={{ padding: '28px 0 40px', borderTop: '1px solid var(--ink-border)' }}>
        <Eyebrow>Kernel API · cheat sheet</Eyebrow>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 14, marginTop: 14 }}>
          {[
            ['plugin-loader', ['registerPlugin(manifest)', 'getActivePlugins(names)', 'mountPluginRoutes(app, names)', 'collectMcpTools(names)', 'collectDashboardWidgets(names)']],
            ['adapter-registry', ['setAdapter("database", d1Adapter)', 'getAdapter("media")', 'hasAdapter("crm")', 'tryGetAdapter("search")']],
            ['roles', ['hasRole(user, required)', 'canAccessPlugin(role, name, active)', 'filterNavByRole(items, role)', 'resolveRole(string)']],
            ['theme', ['generateCssVars() → :root + :root.dark', 'isColorPair(value)', '@media (prefers-color-scheme: dark)']],
            ['types', ['export * from "./ports/generated"', '14 ports · 87 models', 'drift-guarded by SOS CI']],
            ['create-inkwell', ['npx create-inkwell my-site', 'writes instances/<name>/', 'inits git + npm install']],
          ].map(([mod, fns]) => (
            <div key={mod} className="card" style={{ padding: '16px 18px' }}>
              <div style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 11, color: 'var(--ink-primary)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>{mod.includes('/') || mod === 'create-inkwell' ? mod : `kernel/${mod}.ts`}</div>
              {fns.map(fn => (
                <div key={fn} style={{ fontFamily: 'var(--ink-font-mono)', fontSize: 12, color: 'var(--ink-text)', padding: '3px 0', lineHeight: 1.6 }}>{fn}</div>
              ))}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

Object.assign(window, { Architecture });
