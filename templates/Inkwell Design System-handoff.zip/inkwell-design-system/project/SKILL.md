---
name: inkwell
description: Design system for Inkwell — the AI-first, agent-run CMS and business operating system. Dark-first, mono-forward (JetBrains Mono), restrained palette built around ink gold.
---

# Using the Inkwell design system

Inkwell is a CMS that treats agents as first-class authors. The visual tone is **builder-not-marketer**: dark background, JetBrains Mono headings and metrics, system-sans body, and one decisive accent — ink gold (`#D4A017`). Use this system when designing anything that should feel native to Inkwell or a fork of it.

## Load tokens

Every design should import `colors_and_type.css`:

```html
<link rel="stylesheet" href="colors_and_type.css">
<html class="dark"> <!-- or class="light" -->
```

All tokens are CSS custom properties prefixed `--ink-*`. Swap the root class to flip themes; the file ships light + dark values for every token.

## Token cheat sheet

- **Brand:** `--ink-primary` `#D4A017` (gold), `--ink-secondary` `#06B6D4` (cyan), `--ink-accent` `#10B981` (emerald), `--ink-danger` `#EF4444`
- **Neutral (dark):** `--ink-bg` `#0A0A10`, `--ink-surface` `#151519`, `--ink-text` `#EDEDF0`, `--ink-border` `rgba(255,255,255,0.10)`
- **Type:** `--ink-font-display` and `--ink-font-mono` = JetBrains Mono; `--ink-font-body` = system-ui
- **Shape:** `--ink-radius` `6px` (canonical for everything), pills `9999px`
- **Motion:** `--ink-dur-normal` `200ms`, `--ink-ease` `cubic-bezier(.2,.8,.2,1)`

## Semantic type classes (bundled in the CSS)

- `.ink-h1` `.ink-h2` `.ink-h3` `.ink-h4` — JetBrains Mono headings
- `.ink-lead` — oversized body intro (18px, muted)
- `.ink-body` / `.ink-p` — system-sans, line-height 1.8
- `.ink-small` `.ink-caption` — 14 / 12 px respectively
- `.ink-eyebrow` — uppercase mono label (the house eyebrow treatment)
- `.ink-code` — inline `<code>` styling
- `.ink-metric-value` — gold mono metric, 2.5rem

## Composition rules (hard)

1. **Every heading is mono.** No exceptions — h1 through h4 all use JetBrains Mono.
2. **Every number is mono.** Metric values, table data, timestamps, counts.
3. **Body is system-sans.** Paragraphs, form input, chat messages.
4. **Cards have no shadow.** `background: var(--ink-surface); border: 1px solid var(--ink-border); border-radius: 6px;` — depth comes from tone, not elevation.
5. **One accent at a time.** If ink gold is the focus state on an input, don't also add a colored glow — pick one signal.
6. **Sentence case for UI labels.** Buttons, nav items, table headers — never Title Case.
7. **Monocaps for meta labels only.** Eyebrows, status badges, kbd hints — `letter-spacing: 0.05–0.08em`, 10–12px.
8. **Emoji are forbidden** except for the 5-reaction set (🔥 ❤️ 🧠 👏 🚀) which is the literal reaction API.
9. **Unicode as iconography** is encouraged in data contexts: `▲` `▼` for trends, `—` for null, `→` in CTAs, `·` as separator.
10. **No gradients** except the reading-progress bar (`--ink-primary` → `--ink-secondary`, 3px tall).
11. **No background images, no noise, no glass, no neumorphism.** Solid fills.
12. **200ms ease** is the default transition duration. No bounces, no parallax.

## Voice

- Builder, not marketer. Every claim must be backed by something the product can show.
- First-person plural for Inkwell itself; "you" for the reader; "the agent" (or a named agent) for autonomous behavior — never generic "AI."
- Em-dash is the house punctuation. Short declarative sentences. Lists over paragraphs when possible.

## Canonical components to reuse

- **Buttons** — `btn-primary` (gold filled), `btn-ghost` (surface + border flips gold on hover), link variant is mono primary
- **Form inputs** — `var(--ink-bg)` fill, hairline border, radius 4, border flips `--ink-primary` on focus
- **KPI card** — mono uppercase title · mono display value · `▲` or `▼` trend in accent or danger
- **Status badge** — translucent fill (`rgba(color, 0.15)`), mono 10–11px, radius 12
- **Chat bubble** — user: gold + radius `12 12 2 12`; bot: surface + border + radius `12 12 12 2`
- **Command palette** — `max-width: 32rem`, `box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5)`, selected row = 2px left border + `rgba(255,255,255,0.06)` bg
- **Reaction chips** — pills with emoji + mono count; active state = border gold + `rgba(212,160,23,0.10)` fill

## Reference kits in this system

- `preview/` — 18 small cards covering the full token + component surface. Open via the Design System tab.
- `ui_kits/inkwell-site/index.html` — marketing + blog + docs + labs + team + Cmd+K palette. Uses the animated `NetworkHero` canvas for the landing.
- `ui_kits/inkwell-dashboard/index.html` — v4 business OS: overview, contacts, posts, chat inbox, settings. Persistent chat FAB (the one piece of chrome that follows the user).

When building something new, open the relevant kit and lift patterns — don't re-derive them. Colors, radii, badges, and buttons should be copy-paste identical to what's already in `ui_kits/`.

## Flags & substitutions

- **JetBrains Mono** loads from Google Fonts CDN. For offline use, download weights 400/500/600/700 from [fonts.google.com/specimen/JetBrains+Mono](https://fonts.google.com/specimen/JetBrains+Mono) and drop into a local `fonts/` folder.
- **No icon library** is installed in the Inkwell source. In-product icons are hand-authored inline SVGs at 1.5–1.8px stroke, round caps/joins. Where a glyph doesn't already exist in the source, substitute **[Lucide](https://lucide.dev)** — flagged as a substitution.
